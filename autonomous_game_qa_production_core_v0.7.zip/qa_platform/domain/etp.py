from __future__ import annotations
from enum import StrEnum
from typing import Any
from pydantic import BaseModel, ConfigDict, Field
from qa_platform.domain.test_spec import ActionType, Assertion, ExpectedTransition, ObservationRequirement, RetryPolicy, StateRef
class ExecutionStep(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    id:str=Field(min_length=1,max_length=100); action:ActionType; params:dict[str,Any]=Field(default_factory=dict)
    preconditions:tuple[StateRef,...]=(); observation_requirement:ObservationRequirement|None=None; expected_transition:ExpectedTransition|None=None; assertions:tuple[Assertion,...]=(); timeout_ms:int=Field(gt=0,le=600_000); retry_policy:RetryPolicy; idempotent:bool
class ExecutionTestPlan(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    etp_schema_version:str='1.0'; source_spec_version:str='1.0'; test_id:str; name:str; description:str|None=None; tags:tuple[str,...]=(); steps:tuple[ExecutionStep,...]=Field(min_length=1); content_hash:str=Field(pattern=r'^[0-9a-f]{64}$')
