from __future__ import annotations
from enum import StrEnum
from typing import Annotated, Literal, Union
from pydantic import BaseModel, ConfigDict, Field, model_validator

class ActionType(StrEnum):
    OPEN_GAME='open_game'; WAIT='wait'; CLICK='click'; SELECT='select'; ENTER_TEXT='enter_text'; SPIN='spin'; START_AUTOPLAY='start_autoplay'; PAUSE_AUTOPLAY='pause_autoplay'; BET='bet'; SUBMIT='submit'
class AssertionType(StrEnum):
    ELEMENT_VISIBLE='element_visible'; ELEMENT_ENABLED='element_enabled'; TEXT_EQUALS='text_equals'; TEXT_CONTAINS='text_contains'; VALUE_EQUALS='value_equals'; VALUE_IN_RANGE='value_in_range'; STATE_EQUALS='state_equals'
class StateRef(BaseModel):
    model_config=ConfigDict(extra='forbid', frozen=True)
    name:str=Field(min_length=1,max_length=200)
class ExpectedTransition(BaseModel):
    model_config=ConfigDict(extra='forbid', frozen=True)
    from_state:str=Field(min_length=1,max_length=200); to_state:str=Field(min_length=1,max_length=200)
class ObservationRequirement(BaseModel):
    model_config=ConfigDict(extra='forbid', frozen=True)
    target:str=Field(min_length=1,max_length=200); evidence:tuple[str,...]=Field(min_length=1); min_confidence:float=Field(ge=0,le=1); max_age_ms:int=Field(gt=0)
class RetryPolicy(BaseModel):
    model_config=ConfigDict(extra='forbid', frozen=True)
    max_attempts:int=Field(default=1,ge=1,le=10); backoff_ms:int=Field(default=0,ge=0,le=300_000)
class OpenGameParams(BaseModel): model_config=ConfigDict(extra='forbid',frozen=True)
class WaitParams(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    duration_ms:int=Field(gt=0,le=300_000)
class ClickParams(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    target:str=Field(min_length=1,max_length=200)
class SelectParams(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    target:str=Field(min_length=1,max_length=200); value:str|int|float
class EnterTextParams(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    target:str=Field(min_length=1,max_length=200); text:str=Field(max_length=10_000)
class SpinParams(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    count:int=Field(default=1,ge=1,le=10_000)
class AutoplayParams(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    count:int=Field(default=1,ge=1,le=10_000)
class BetParams(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    amount:float=Field(gt=0)
class SubmitParams(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    target:str=Field(min_length=1,max_length=200)

class Assertion(BaseModel):
    model_config=ConfigDict(extra='forbid', frozen=True)
    type:AssertionType; target:str|None=None; expected:str|int|float|bool|None=None; min_value:float|None=None; max_value:float|None=None
    @model_validator(mode='after')
    def validate_semantics(self):
        target_required={AssertionType.ELEMENT_VISIBLE,AssertionType.ELEMENT_ENABLED,AssertionType.TEXT_EQUALS,AssertionType.TEXT_CONTAINS,AssertionType.VALUE_EQUALS,AssertionType.VALUE_IN_RANGE,AssertionType.STATE_EQUALS}
        if self.type in target_required and not self.target: raise ValueError(f'{self.type.value} requires target')
        if self.type is AssertionType.VALUE_IN_RANGE and (self.min_value is None or self.max_value is None or self.min_value>self.max_value): raise ValueError('value_in_range requires ordered min_value/max_value')
        return self

ActionParams = Annotated[Union[
    OpenGameParams,WaitParams,ClickParams,SelectParams,EnterTextParams,SpinParams,AutoplayParams,BetParams,SubmitParams
], Field(discriminator='kind')]
# Pydantic discriminator is not useful with external action enum, so TestStep validates explicitly.

class TestStep(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    id:str=Field(min_length=1,max_length=100); action:ActionType; params:dict[str,object]=Field(default_factory=dict)
    preconditions:tuple[StateRef,...]=(); observation_requirement:ObservationRequirement|None=None; expected_transition:ExpectedTransition|None=None; assertions:tuple[Assertion,...]=()
    timeout_ms:int=Field(default=30_000,gt=0,le=600_000); retry_policy:RetryPolicy=RetryPolicy(); idempotent:bool=True
    @model_validator(mode='after')
    def validate_action_params(self):
        models={ActionType.OPEN_GAME:OpenGameParams,ActionType.WAIT:WaitParams,ActionType.CLICK:ClickParams,ActionType.SELECT:SelectParams,ActionType.ENTER_TEXT:EnterTextParams,ActionType.SPIN:SpinParams,ActionType.START_AUTOPLAY:AutoplayParams,ActionType.PAUSE_AUTOPLAY:OpenGameParams,ActionType.BET:BetParams,ActionType.SUBMIT:SubmitParams}
        model=models[self.action]
        model.model_validate(self.params)
        if self.action in {ActionType.CLICK,ActionType.SELECT,ActionType.ENTER_TEXT,ActionType.SUBMIT} and self.observation_requirement is None:
            raise ValueError(f'{self.action.value} requires observation_requirement')
        if self.retry_policy.max_attempts>1 and not self.idempotent and self.action not in {ActionType.WAIT,ActionType.OPEN_GAME}:
            raise ValueError('non-idempotent actions cannot have automatic retries')
        return self

class TestSpec(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    test_id:str=Field(min_length=1,max_length=200); name:str=Field(min_length=1,max_length=300); description:str|None=Field(default=None,max_length=10_000); tags:tuple[str,...]=(); steps:tuple[TestStep,...]=Field(min_length=1)
    @model_validator(mode='after')
    def validate_unique_step_ids(self):
        ids=[s.id for s in self.steps]
        if len(ids)!=len(set(ids)): raise ValueError('step ids must be unique')
        return self
TestSpec.__test__ = False
TestStep.__test__ = False
