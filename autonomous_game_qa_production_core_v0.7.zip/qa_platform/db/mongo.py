from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pymongo import AsyncMongoClient

from qa_platform.config import Settings
from qa_platform.etp.services import ETPService
from qa_platform.compiler.compiler import ExecutionTestPlanCompiler
from qa_platform.game_registry.services import GameRegistryService
from qa_platform.repositories.mongodb_etp_repository import MongoDBETPRepository
from qa_platform.repositories.mongodb_game_repository import MongoDBGameRepository


@dataclass
class MongoDatabase:
    client: AsyncMongoClient[dict[str, Any]]
    database: Any
    etp_repository: MongoDBETPRepository
    game_repository: MongoDBGameRepository
    etp_service: ETPService
    game_service: GameRegistryService

    @classmethod
    async def connect(cls, settings: Settings) -> "MongoDatabase":
        client: AsyncMongoClient[dict[str, Any]] = AsyncMongoClient(
            settings.mongodb_uri,
            serverSelectionTimeoutMS=settings.mongodb_server_selection_timeout_ms,
            connectTimeoutMS=settings.mongodb_connect_timeout_ms,
        )

        # Force a real server selection during startup instead of allowing
        # the first request to discover a broken MongoDB connection.
        await client.admin.command("ping")

        database = client[settings.mongodb_database]

        etp_repository = MongoDBETPRepository(
            database[MongoDBETPRepository.COLLECTION_NAME]
        )
        game_repository = MongoDBGameRepository(
            database[MongoDBGameRepository.COLLECTION_NAME]
        )

        etp_service = ETPService(
            repository=etp_repository,
            compiler=ExecutionTestPlanCompiler(),
        )
        game_service = GameRegistryService(game_repository)

        # Index creation is the application's responsibility. MongoDB creates
        # the collection automatically when the first index/document is added.
        await etp_service.initialize()
        await game_service.initialize()

        return cls(
            client=client,
            database=database,
            etp_repository=etp_repository,
            game_repository=game_repository,
            etp_service=etp_service,
            game_service=game_service,
        )

    async def ping(self) -> bool:
        try:
            await self.client.admin.command("ping")
            return True
        except Exception:
            return False

    def close(self) -> None:
        self.client.close()
