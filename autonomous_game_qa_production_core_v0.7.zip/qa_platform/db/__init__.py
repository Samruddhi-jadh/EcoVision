from qa_platform.db.mongo import MongoDatabase

__all__ = ["MongoDatabase"]
