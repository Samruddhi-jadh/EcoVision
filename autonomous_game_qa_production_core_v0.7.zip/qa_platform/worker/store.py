from __future__ import annotations
import asyncio
from datetime import datetime,timezone,timedelta
from typing import Protocol
from qa_platform.execution.models import RunManifest,RunStatus,Verdict
class RunStore(Protocol):
    async def create(self,manifest:RunManifest)->None: ...
    async def get_manifest(self,run_id:str)->RunManifest: ...
    async def set_status(self,run_id:str,status:RunStatus,verdict:Verdict|None=None)->None: ...
    async def get_status(self,run_id:str)->RunStatus: ...
    async def acquire_lease(self,run_id:str,owner:str,ttl_seconds:int)->bool: ...
    async def release_lease(self,run_id:str,owner:str)->None: ...
class InMemoryRunStore:
    def __init__(self): self.manifests={}; self.status={}; self.verdict={}; self.leases={}; self.lock=asyncio.Lock()
    async def create(self,manifest):
        async with self.lock:
            if manifest.run_id in self.manifests: raise ValueError('run already exists')
            self.manifests[manifest.run_id]=manifest; self.status[manifest.run_id]=RunStatus.CREATED
    async def get_manifest(self,run_id): return self.manifests[run_id]
    async def set_status(self,run_id,status,verdict=None):
        async with self.lock: self.status[run_id]=status; self.verdict[run_id]=verdict
    async def get_status(self,run_id): return self.status[run_id]
    async def acquire_lease(self,run_id,owner,ttl_seconds):
        async with self.lock:
            now=datetime.now(timezone.utc); cur=self.leases.get(run_id)
            if cur and cur[1]>now and cur[0]!=owner:return False
            self.leases[run_id]=(owner,now+timedelta(seconds=ttl_seconds)); return True
    async def release_lease(self,run_id,owner):
        async with self.lock:
            if self.leases.get(run_id,(None,None))[0]==owner:self.leases.pop(run_id,None)
