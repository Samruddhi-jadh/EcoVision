from __future__ import annotations
import asyncio,uuid
from qa_platform.queue.models import QueueMessage
from qa_platform.queue.protocol import DurableQueue
from qa_platform.worker.store import RunStore
from qa_platform.execution.models import RunStatus,Verdict
class ExecutionWorker:
    def __init__(self,*,queue:DurableQueue,store:RunStore,controller_factory,etp_loader,game_loader,consumer='worker-1',max_delivery_attempts=3,lease_seconds=120):
        self.queue=queue; self.store=store; self.controller_factory=controller_factory; self.etp_loader=etp_loader; self.game_loader=game_loader; self.consumer=consumer; self.max_delivery_attempts=max_delivery_attempts; self.lease_seconds=lease_seconds; self._stop=asyncio.Event()
    def stop(self): self._stop.set()
    async def run_forever(self):
        while not self._stop.is_set():
            for message in await self.queue.consume(consumer=self.consumer,count=1,block_ms=1000): await self.process(message)
    async def process(self,msg:QueueMessage):
        status=await self.store.get_status(msg.run_id)
        if status is RunStatus.TERMINAL: await self.queue.ack(msg); return
        if status is RunStatus.RUNNING:
            # A running run is never replayed by a second delivery. A reconciliation job
            # must decide whether an orphaned RUNNING run becomes INCONCLUSIVE/BLOCKED.
            await self.queue.ack(msg); return
        try:
            manifest=await self.store.get_manifest(msg.run_id)
            etp=await self.etp_loader(manifest); game=await self.game_loader(manifest)
            if etp.test_id!=manifest.test_id or game.version!=manifest.game_version or game.build_hash.lower()!=manifest.game_build_hash.lower(): raise RuntimeError('manifest pin mismatch')
        except Exception as exc:
            if msg.attempt < self.max_delivery_attempts:
                await self.queue.enqueue(msg.model_copy(update={'attempt':msg.attempt+1})); await self.queue.ack(msg); return
            await self.store.set_status(msg.run_id,RunStatus.FAILED); await self.queue.dead_letter(msg,f'pre-execution load failure: {exc}'); await self.queue.ack(msg); return
        owner=f'{self.consumer}:{uuid.uuid4()}'
        if not await self.store.acquire_lease(msg.run_id,owner,self.lease_seconds): await self.queue.ack(msg); return
        await self.store.set_status(msg.run_id,RunStatus.RUNNING)
        try:
            verdict=await self.controller_factory().run(manifest=manifest,etp=etp,game=game)
            await self.store.set_status(msg.run_id,RunStatus.TERMINAL,verdict)
            await self.queue.ack(msg)
        except asyncio.CancelledError:
            await self.store.set_status(msg.run_id,RunStatus.TERMINAL,Verdict.CANCELLED); await self.queue.ack(msg); raise
        except Exception as exc:
            # Never replay a partially executed run. The event log is authoritative;
            # reconciliation can classify this run as INCONCLUSIVE/BLOCKED.
            await self.store.set_status(msg.run_id,RunStatus.TERMINAL,Verdict.INCONCLUSIVE)
            await self.queue.dead_letter(msg,f'execution failure after lease acquisition: {exc}')
            await self.queue.ack(msg)
        finally:
            await self.store.release_lease(msg.run_id,owner)
