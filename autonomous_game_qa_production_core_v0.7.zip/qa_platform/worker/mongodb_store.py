from __future__ import annotations
from datetime import datetime,timezone
from pymongo import ASCENDING
from pymongo.asynchronous.collection import AsyncCollection
from qa_platform.execution.models import RunManifest,RunStatus,Verdict
class MongoRunStore:
    def __init__(self,collection:AsyncCollection[dict]): self.collection=collection
    async def ensure_indexes(self):
        await self.collection.create_index([('run_id',ASCENDING)],unique=True,name='uq_run_id')
        await self.collection.create_index([('status',ASCENDING),('created_at',ASCENDING)],name='ix_run_status_created')
    async def create(self,manifest):
        await self.collection.insert_one({'run_id':manifest.run_id,'manifest':manifest.model_dump(mode='json'),'status':RunStatus.CREATED.value,'verdict':None,'created_at':manifest.created_at})
    async def get_manifest(self,run_id):
        doc=await self.collection.find_one({'run_id':run_id})
        if not doc: raise KeyError(run_id)
        return RunManifest.model_validate(doc['manifest'])
    async def set_status(self,run_id,status,verdict=None):
        update={'status':status.value,'updated_at':datetime.now(timezone.utc)}
        if verdict is not None: update['verdict']=verdict.value
        await self.collection.update_one({'run_id':run_id},{'$set':update})
    async def get_status(self,run_id):
        doc=await self.collection.find_one({'run_id':run_id},{'status':1})
        if not doc: raise KeyError(run_id)
        return RunStatus(doc['status'])
