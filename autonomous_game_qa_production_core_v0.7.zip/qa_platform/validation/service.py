from __future__ import annotations
from qa_platform.domain.etp import ExecutionTestPlan,ActionType
from qa_platform.etp.models import ETPVersion,ETPVersionStatus
from qa_platform.game_registry.models import GameVersion,GameVersionStatus,GameCapability
from qa_platform.validation.models import *
from qa_platform.validation.codes import *
from qa_platform.compiler.compiler import verify_etp_hash

class BatchValidationService:
    def validate(self, *, etp_version:ETPVersion, etp:ExecutionTestPlan, game:GameVersion, browser:str, browser_version:str, max_run_ms:int=3_600_000)->BatchValidationResult:
        checks=[]; errors=[]; warnings=[]
        def check(code,status,msg,details=None): checks.append(ValidationCheck(code=code,status=status,message=msg,details=details or {}))
        def err(code,msg,details=None): errors.append(ValidationIssue(code=code,severity=ValidationSeverity.ERROR,message=msg,details=details or {}))
        if etp_version.status is not ETPVersionStatus.APPROVED: check(ETP_NOT_APPROVED,ValidationStatus.INVALID,'ETP version is not APPROVED'); err(ETP_NOT_APPROVED,'Only APPROVED ETP versions are executable.')
        else: check(ETP_NOT_APPROVED,ValidationStatus.VALID,'ETP version is approved')
        if etp.test_id != etp_version.test_id: check(ETP_ID_MISMATCH,ValidationStatus.INVALID,'ETP test_id mismatch'); err(ETP_ID_MISMATCH,'ETP test_id does not match stored version.')
        elif not verify_etp_hash(etp) or etp.content_hash!=etp_version.content_hash: check(ETP_HASH_MISMATCH,ValidationStatus.INVALID,'ETP hash mismatch'); err(ETP_HASH_MISMATCH,'ETP content hash is invalid or does not match stored metadata.')
        else: check('ETP_INTEGRITY',ValidationStatus.VALID,'ETP integrity verified')
        if not etp.steps: check(EMPTY_STEPS,ValidationStatus.INVALID,'ETP contains no steps'); err(EMPTY_STEPS,'ETP must contain at least one step.')
        else: check('ETP_SCHEMA',ValidationStatus.VALID,'ETP schema is valid')
        if game.status is GameVersionStatus.ACTIVE: check(GAME_NOT_ACTIVE,ValidationStatus.VALID,'Game version is ACTIVE')
        elif game.status is GameVersionStatus.DRAFT: check(GAME_NOT_ACTIVE,ValidationStatus.BLOCKED,'Game version is not activated'); errors.append(ValidationIssue(code=GAME_NOT_ACTIVE,severity=ValidationSeverity.ERROR,message='Only ACTIVE game versions can execute runs.'))
        else: check(GAME_NOT_ACTIVE,ValidationStatus.INVALID,'Game version is deprecated'); err(GAME_NOT_ACTIVE,'Deprecated game versions cannot execute new runs.')
        required=self._required_capabilities(etp)
        missing=sorted(c.value for c in required if c not in game.config.capabilities)
        if missing: check(GAME_CAPABILITY_MISSING,ValidationStatus.INVALID,'Game is missing required capabilities',{'missing':missing}); err(GAME_CAPABILITY_MISSING,'Required game capabilities are unavailable.',{'missing':missing})
        else: check(GAME_CAPABILITY_MISSING,ValidationStatus.VALID,'Required capabilities are available')
        target_ids={t.target_id for t in game.config.targets}; missing_targets=sorted(self._targets(etp)-target_ids)
        if missing_targets: check(TARGET_NOT_FOUND,ValidationStatus.INVALID,'ETP references unknown targets',{'missing':missing_targets}); err(TARGET_NOT_FOUND,'All semantic targets must resolve in the exact GameVersion.',{'missing':missing_targets})
        else: check(TARGET_NOT_FOUND,ValidationStatus.VALID,'All ETP targets resolve')
        browser_reqs=[b for b in game.config.browsers if b.browser.lower()==browser.lower()]
        if game.config.browsers and not browser_reqs: check(BROWSER_UNSUPPORTED,ValidationStatus.INVALID,'Browser is not supported by GameVersion'); err(BROWSER_UNSUPPORTED,'Requested browser is not supported.',{'browser':browser})
        elif browser_reqs and not any(self._version_allowed(browser_version,r.min_version,r.max_version) for r in browser_reqs): check(BROWSER_UNSUPPORTED,ValidationStatus.INVALID,'Browser version is outside the supported range'); err(BROWSER_UNSUPPORTED,'Requested browser version is outside the GameVersion range.',{'browser_version':browser_version})
        else: check(BROWSER_UNSUPPORTED,ValidationStatus.VALID,'Browser is supported')
        provider_errors=[]
        for step in etp.steps:
            if step.observation_requirement:
                for provider in step.observation_requirement.evidence:
                    p=provider.lower()
                    enabled={'runtime':game.config.perception.runtime_enabled,'dom':game.config.perception.dom_enabled,'ocr':game.config.perception.ocr_enabled,'cv':game.config.perception.cv_enabled,'yolo':game.config.perception.yolo_enabled,'vlm':game.config.perception.vlm_enabled}.get(p)
                    if enabled is False: provider_errors.append((step.id,p))
                    if p=='vlm' and game.config.perception.vlm_max_calls_per_step<1: provider_errors.append((step.id,p))
        if provider_errors: check(PERCEPTION_UNAVAILABLE,ValidationStatus.INVALID,'Required perception provider is unavailable',{'requirements':provider_errors}); err(PERCEPTION_UNAVAILABLE,'A required perception provider is disabled.',{'requirements':provider_errors})
        else: check(PERCEPTION_UNAVAILABLE,ValidationStatus.VALID,'Required perception providers are available')
        if max_run_ms<=0: check(POLICY_TIMEOUT,ValidationStatus.INVALID,'Run budget invalid'); err(POLICY_TIMEOUT,'Run budget must be positive.')
        for step in etp.steps:
            if step.timeout_ms>max_run_ms: err(POLICY_TIMEOUT,f'Step {step.id} exceeds run budget.',{'step_id':step.id})
            if step.retry_policy.max_attempts>1 and not step.idempotent: err(NON_IDEMPOTENT_RETRY,f'Step {step.id} retries a non-idempotent action.',{'step_id':step.id})
        check('EXECUTION_POLICY',ValidationStatus.INVALID if errors else ValidationStatus.VALID,'Execution policy constraints evaluated')
        status=ValidationStatus.INVALID if errors else ValidationStatus.VALID
        if any(c.status is ValidationStatus.BLOCKED for c in checks): status=ValidationStatus.BLOCKED
        return BatchValidationResult(status=status,checks=tuple(checks),errors=tuple(errors),warnings=tuple(warnings))
    @staticmethod
    def _version_allowed(actual,min_version,max_version):
        def key(v):
            return tuple(int(x) if x.isdigit() else 0 for x in v.split('.'))
        try:
            a=key(actual); return (min_version is None or a>=key(min_version)) and (max_version is None or a<=key(max_version))
        except Exception: return False
    @staticmethod
    def _targets(etp):
        out=set()
        for s in etp.steps:
            if 'target' in s.params and isinstance(s.params['target'],str): out.add(s.params['target'])
            if s.observation_requirement: out.add(s.observation_requirement.target)
            out.update(a.target for a in s.assertions if a.target and a.type.value in {'element_visible','element_enabled','text_equals','text_contains','value_equals','value_in_range'})
        return out
    @staticmethod
    def _required_capabilities(etp):
        req=set()
        for s in etp.steps:
            if s.action is ActionType.SPIN: req.add(GameCapability.MANUAL_SPIN)
            if s.action in {ActionType.START_AUTOPLAY,ActionType.PAUSE_AUTOPLAY}: req.add(GameCapability.AUTOPLAY)
            if s.action is ActionType.BET: req.add(GameCapability.BETTING)
            if s.observation_requirement and any(x.lower()=='ocr' for x in s.observation_requirement.evidence): req.add(GameCapability.OCR)
        return frozenset(req)
