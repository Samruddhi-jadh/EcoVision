from __future__ import annotations
from enum import StrEnum
from pydantic import BaseModel,ConfigDict,Field
class ValidationStatus(StrEnum): VALID='VALID'; INVALID='INVALID'; BLOCKED='BLOCKED'
class ValidationSeverity(StrEnum): ERROR='ERROR'; WARNING='WARNING'
class ValidationCheck(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    code:str; status:ValidationStatus; message:str; details:dict[str,object]=Field(default_factory=dict)
class ValidationIssue(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    code:str; severity:ValidationSeverity; message:str; details:dict[str,object]=Field(default_factory=dict)
class BatchValidationResult(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    status:ValidationStatus; checks:tuple[ValidationCheck,...]; errors:tuple[ValidationIssue,...]=(); warnings:tuple[ValidationIssue,...]=()
    @property
    def executable(self): return self.status is ValidationStatus.VALID
