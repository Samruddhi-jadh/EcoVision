from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from qa_platform.game_registry.models import (
    GameCapability,
    GameConfig,
    GameVersion,
    GameVersionStatus,
)

from qa_platform.repositories.game_repository import (
    GameAlreadyExistsError,
    GameNotFoundError,
    GameRepository,
    GameVersionNotFoundError,
)


class GameConfigValidationError(ValueError):
    pass


class GameRegistryService:

    MAX_VERSION_ALLOCATION_RETRIES = 5

    def __init__(
        self,
        repository: GameRepository,
    ) -> None:
        self._repository = repository

    async def initialize(self) -> None:
        await self._repository.ensure_indexes()

    async def register_version(
        self,
        *,
        game_id: str,
        build_id: str,
        build_hash: str,
        config: GameConfig,
    ) -> GameVersion:

        # Same immutable build should be idempotent.
        existing = await self._repository.find_by_build_hash(
            game_id,
            build_hash,
        )

        if existing is not None:
            return existing

        for _ in range(
            self.MAX_VERSION_ALLOCATION_RETRIES
        ):
            latest = await self._repository.get_latest_version(
                game_id
            )

            next_version = (
                1
                if latest is None
                else latest.version + 1
            )

            candidate = GameVersion(
                game_id=game_id,
                version=next_version,
                build_id=build_id,
                build_hash=build_hash,
                status=GameVersionStatus.DRAFT,
                config=config,
                created_at=datetime.now(timezone.utc),
            )

            try:
                return await self._repository.create_version(
                    candidate
                )

            except GameAlreadyExistsError:

                # Another writer allocated the same version.
                #
                # Re-read the build hash before retrying. Another
                # writer may have registered exactly this build.
                existing = (
                    await self._repository.find_by_build_hash(
                        game_id,
                        build_hash,
                    )
                )

                if existing is not None:
                    return existing

                await asyncio.sleep(0)

        raise GameAlreadyExistsError(
            f"could not allocate game version for "
            f"{game_id} after "
            f"{self.MAX_VERSION_ALLOCATION_RETRIES} retries"
        )

    async def get_version(
        self,
        game_id: str,
        version: int,
    ) -> GameVersion:

        return await self._repository.get_version(
            game_id,
            version,
        )

    async def get_active(
        self,
        game_id: str,
    ) -> GameVersion:

        version = (
            await self._repository.get_active_version(
                game_id
            )
        )

        if version is None:
            raise GameNotFoundError(
                f"no active version for {game_id}"
            )

        return version

    async def activate(
        self,
        game_id: str,
        version: int,
    ) -> GameVersion:

        return await self._repository.activate_version(
            game_id,
            version,
        )

    async def deprecate(
        self,
        game_id: str,
        version: int,
    ) -> GameVersion:

        return await self._repository.deprecate_version(
            game_id,
            version,
        )

    @staticmethod
    def check_compatibility(
        game: GameVersion,
        required_capabilities: frozenset[
            GameCapability
        ],
    ) -> tuple[bool, tuple[str, ...]]:

        missing = tuple(
            sorted(
                capability.value
                for capability in required_capabilities
                if capability
                not in game.config.capabilities
            )
        )

        return (
            not missing,
            missing,
        )