from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        str_strip_whitespace=True,
    )


class GameVersionStatus(StrEnum):
    DRAFT = "DRAFT"
    ACTIVE = "ACTIVE"
    DEPRECATED = "DEPRECATED"


class GameEnvironment(StrEnum):
    LOCAL = "LOCAL"
    TEST = "TEST"
    STAGING = "STAGING"
    PRODUCTION = "PRODUCTION"


class GameCapability(StrEnum):
    AUTOPLAY = "AUTOPLAY"
    MANUAL_SPIN = "MANUAL_SPIN"
    BETTING = "BETTING"
    OVERLAY = "OVERLAY"
    DOM_INSPECTION = "DOM_INSPECTION"
    CANVAS = "CANVAS"
    OCR = "OCR"
    YOLO = "YOLO"


class BrowserRequirement(StrictModel):
    browser: Annotated[str, Field(min_length=1, max_length=64)]
    min_version: Annotated[str | None, Field(max_length=64)] = None
    max_version: Annotated[str | None, Field(max_length=64)] = None
    headless_supported: bool = True


class TargetDefinition(StrictModel):
    target_id: Annotated[
        str,
        Field(pattern=r"^[a-zA-Z0-9_.:-]{1,128}$"),
    ]

    description: Annotated[
        str,
        Field(min_length=1, max_length=500),
    ]

    kind: Annotated[
        str,
        Field(pattern=r"^[a-zA-Z0-9_.:-]{1,64}$"),
    ]

    selector: Annotated[
        str | None,
        Field(max_length=1000),
    ] = None

    semantic_name: Annotated[
        str | None,
        Field(max_length=256),
    ] = None

    @model_validator(mode="after")
    def validate_resolution_strategy(self) -> "TargetDefinition":
        if not self.selector and not self.semantic_name:
            raise ValueError(
                "target requires selector or semantic_name"
            )

        return self


class PerceptionConfig(StrictModel):
    runtime_enabled: bool = True
    dom_enabled: bool = True
    ocr_enabled: bool = True
    cv_enabled: bool = True
    yolo_enabled: bool = True

    # Important:
    # This does NOT mean the VLM becomes a normal execution mechanism.
    # It remains a fallback perception provider.
    vlm_enabled: bool = False

    vlm_max_calls_per_step: Annotated[
        int,
        Field(ge=0, le=10),
    ] = 1


class GameConfig(StrictModel):
    environment: GameEnvironment

    base_url: HttpUrl

    capabilities: frozenset[GameCapability] = frozenset()

    browsers: tuple[BrowserRequirement, ...] = ()

    targets: tuple[TargetDefinition, ...] = ()

    perception: PerceptionConfig = PerceptionConfig()

    default_action_timeout_ms: Annotated[
        int,
        Field(ge=100, le=300_000),
    ] = 10_000

    default_observation_timeout_ms: Annotated[
        int,
        Field(ge=100, le=300_000),
    ] = 10_000

    metadata: dict[str, str] = {}

    @field_validator("browsers")
    @classmethod
    def validate_unique_browsers(
        cls,
        value: tuple[BrowserRequirement, ...],
    ) -> tuple[BrowserRequirement, ...]:
        names = [
            browser.browser.lower()
            for browser in value
        ]

        if len(names) != len(set(names)):
            raise ValueError(
                "duplicate browser requirement"
            )

        return value

    @field_validator("targets")
    @classmethod
    def validate_unique_targets(
        cls,
        value: tuple[TargetDefinition, ...],
    ) -> tuple[TargetDefinition, ...]:
        ids = [
            target.target_id
            for target in value
        ]

        if len(ids) != len(set(ids)):
            raise ValueError(
                "duplicate target_id"
            )

        return value

    @model_validator(mode="after")
    def validate_capabilities(self) -> "GameConfig":

        if (
            GameCapability.CANVAS not in self.capabilities
            and not self.targets
        ):
            raise ValueError(
                "non-canvas game must define at least one target"
            )

        if (
            self.perception.vlm_enabled
            and GameCapability.CANVAS not in self.capabilities
        ):
            raise ValueError(
                "VLM perception requires CANVAS capability"
            )

        return self


class GameVersion(StrictModel):
    game_id: Annotated[
        str,
        Field(
            pattern=r"^[a-z0-9][a-z0-9_.-]{1,127}$"
        ),
    ]

    version: Annotated[
        int,
        Field(ge=1),
    ]

    build_id: Annotated[
        str,
        Field(min_length=1, max_length=256),
    ]

    build_hash: Annotated[
        str,
        Field(pattern=r"^[a-fA-F0-9]{64}$"),
    ]

    status: GameVersionStatus = GameVersionStatus.DRAFT

    config: GameConfig

    created_at: datetime

    activated_at: datetime | None = None

    deprecated_at: datetime | None = None

    @model_validator(mode="after")
    def validate_lifecycle(self) -> "GameVersion":

        if (
            self.status is GameVersionStatus.DRAFT
            and self.activated_at is not None
        ):
            raise ValueError(
                "DRAFT version cannot have activated_at"
            )

        if (
            self.status is GameVersionStatus.ACTIVE
            and self.activated_at is None
        ):
            raise ValueError(
                "ACTIVE version requires activated_at"
            )

        if (
            self.status is GameVersionStatus.DEPRECATED
            and self.deprecated_at is None
        ):
            raise ValueError(
                "DEPRECATED version requires deprecated_at"
            )

        if (
            self.activated_at
            and self.deprecated_at
            and self.deprecated_at < self.activated_at
        ):
            raise ValueError(
                "deprecated_at cannot precede activated_at"
            )

        return self