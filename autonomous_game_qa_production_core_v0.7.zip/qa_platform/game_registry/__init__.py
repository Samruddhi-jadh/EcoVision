"""Game registry domain models and services.

Keep package initialization side-effect free; import models/services directly
from their modules to avoid repository/service circular imports.
"""
