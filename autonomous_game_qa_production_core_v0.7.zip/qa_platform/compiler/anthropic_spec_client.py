from __future__ import annotations
import anthropic
import instructor
from qa_platform.domain.test_spec import TestSpec
class AnthropicTestSpecClient:
    """Anthropic + Instructor adapter for AI Call #1.

    Instructor's current provider API is used intentionally; the older
    from_anthropic()/chat.completions pattern is not used.
    """
    def __init__(self, *, api_key:str, model:str, max_retries:int=2, timeout_seconds:float=60.0) -> None:
        if not api_key.strip(): raise ValueError('api_key must not be empty')
        if not model.strip(): raise ValueError('model must not be empty')
        self._model=model
        self._max_retries=max_retries
        self._client=instructor.from_provider(f'anthropic/{model}',async_client=True,api_key=api_key,timeout=timeout_seconds)
    async def generate_test_spec(self, *, system_prompt:str, test_case:str, model:str) -> TestSpec:
        if model != self._model: raise ValueError('model differs from pinned client model')
        return await self._client.create(response_model=TestSpec,max_retries=self._max_retries,messages=[{'role':'system','content':system_prompt},{'role':'user','content':test_case}],max_tokens=8_000,temperature=0)
