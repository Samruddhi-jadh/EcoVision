from __future__ import annotations

import hashlib
import json
from typing import Any

from qa_platform.domain.etp import ExecutionStep, ExecutionTestPlan
from qa_platform.domain.test_spec import TestSpec


class CompilationError(ValueError):
    """Raised when a TestSpec cannot be compiled into an ETP."""


class ExecutionTestPlanCompiler:
    """
    Deterministic TestSpec → ETP compiler.

    This class NEVER calls an LLM.
    """

    def compile(self, spec: TestSpec) -> ExecutionTestPlan:
        try:
            steps = tuple(
                self._compile_step(step)
                for step in spec.steps
            )

            payload: dict[str, Any] = {
                "etp_schema_version": "1.0",
                "source_spec_version": "1.0",
                "test_id": spec.test_id,
                "name": spec.name,
                "description": spec.description,
                "tags": list(spec.tags),
                "steps": [
                    step.model_dump(mode="json")
                    for step in steps
                ],
            }

            content_hash = self._hash_payload(payload)

            return ExecutionTestPlan(
                **payload,
                content_hash=content_hash,
            )

        except Exception as exc:
            if isinstance(exc, CompilationError):
                raise

            raise CompilationError(
                "Failed to compile TestSpec into ETP."
            ) from exc

    def _compile_step(self, step: Any) -> ExecutionStep:
        return ExecutionStep(
            id=step.id,
            action=step.action.value,
            params=dict(step.params),
            preconditions=tuple(
                item.model_dump(mode="json")
                for item in step.preconditions
            ),
            observation_requirement=(
                step.observation_requirement.model_dump(mode="json")
                if step.observation_requirement
                else None
            ),
            expected_transition=(
                step.expected_transition.model_dump(mode="json")
                if step.expected_transition
                else None
            ),
            assertions=tuple(
                assertion.model_dump(mode="json")
                for assertion in step.assertions
            ),
            timeout_ms=step.timeout_ms,
            retry_policy=step.retry_policy.model_dump(mode="json"),
            idempotent=step.idempotent,
        )

    @staticmethod
    def _hash_payload(payload: dict[str, Any]) -> str:
        canonical = json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")

        return hashlib.sha256(canonical).hexdigest()


def verify_etp_hash(etp: ExecutionTestPlan) -> bool:
    payload = etp.model_dump(mode="json")

    payload.pop("content_hash", None)

    canonical = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")

    expected = hashlib.sha256(canonical).hexdigest()

    return expected == etp.content_hash