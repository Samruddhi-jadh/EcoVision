from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


from qa_platform.domain.test_spec import TestSpec

from .prompts import PROMPT_VERSION, SYSTEM_PROMPT


class LLMCompilationError(RuntimeError):
    """Raised when AI Test Compiler cannot produce valid TestSpec."""


@dataclass(frozen=True)
class CompilerMetadata:
    model: str
    prompt_version: str
    provider: str


class StructuredTestSpecClient(Protocol):
    async def generate_test_spec(
        self,
        *,
        system_prompt: str,
        test_case: str,
        model: str,
    ) -> TestSpec:
        ...


class LLMTestCompiler:
    """
    AI Call #1.

    Natural-language Test Case → validated TestSpec.

    The returned TestSpec is then passed to the deterministic compiler.
    """

    def __init__(
        self,
        client: StructuredTestSpecClient,
        *,
        model: str,
    ) -> None:
        self._client = client
        self._model = model

    async def compile(
        self,
        *,
        test_case: str,
    ) -> tuple[TestSpec, CompilerMetadata]:
        if not test_case.strip():
            raise LLMCompilationError(
                "Test case must not be empty."
            )

        try:
            spec = await self._client.generate_test_spec(
                system_prompt=SYSTEM_PROMPT,
                test_case=test_case,
                model=self._model,
            )
        except Exception as exc:
            raise LLMCompilationError(
                "AI Test Compiler failed to produce a TestSpec."
            ) from exc

        if not isinstance(spec, TestSpec):
            raise LLMCompilationError(
                "AI Test Compiler returned an invalid TestSpec."
            )

        return (
            spec,
            CompilerMetadata(
                model=self._model,
                prompt_version=PROMPT_VERSION,
                provider="anthropic",
            ),
        )