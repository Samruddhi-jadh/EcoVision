from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    mongodb_uri: str
    mongodb_database: str
    redis_url: str
    test_compiler_model: str
    test_compiler_prompt_version: str
    anthropic_api_key: str
    mongodb_server_selection_timeout_ms: int = 5_000
    mongodb_connect_timeout_ms: int = 5_000

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            mongodb_uri=os.getenv(
                "MONGODB_URI",
                "mongodb://localhost:27017/qa_platform",
            ),
            mongodb_database=os.getenv(
                "MONGODB_DATABASE",
                "qa_platform",
            ),
            redis_url=os.getenv(
                "REDIS_URL",
                "redis://localhost:6379/0",
            ),
            test_compiler_model=os.getenv(
                "TEST_COMPILER_MODEL",
                "claude-sonnet-4-5",
            ),
            test_compiler_prompt_version=os.getenv(
                "TEST_COMPILER_PROMPT_VERSION",
                "test-compiler-v1",
            ),
            anthropic_api_key=os.getenv(
                "ANTHROPIC_API_KEY",
                "",
            ),
        )
