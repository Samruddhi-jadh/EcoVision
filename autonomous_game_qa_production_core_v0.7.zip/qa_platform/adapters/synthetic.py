from __future__ import annotations
from datetime import datetime,timezone
import hashlib
from qa_platform.execution.models import Observation,EvidenceKind
class ScriptedObserver:
    def __init__(self,states): self.states=list(states); self.i=0
    async def observe(self,*,requirement,game):
        state=self.states[min(self.i,len(self.states)-1)]; self.i+=1
        now=datetime.now(timezone.utc)
        return Observation(observed_at=now,frame_hash=hashlib.sha256(f'{self.i}:{state}'.encode()).hexdigest(),fields={'state':state,**({'visible':True} if requirement.target!='__game__' else {})},evidence=(EvidenceKind.RUNTIME,),confidence=1.0)
class RecordingExecutor:
    def __init__(self): self.actions=[]
    async def execute(self,*,action,game,manifest):
        now=datetime.now(timezone.utc); self.actions.append(action); return now
