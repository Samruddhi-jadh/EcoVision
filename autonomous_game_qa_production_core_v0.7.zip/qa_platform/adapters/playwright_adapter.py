from __future__ import annotations
import hashlib,json,asyncio
from datetime import datetime,timezone
from typing import Any
from qa_platform.execution.models import Observation,EvidenceKind,SemanticAction,RunManifest
from qa_platform.game_registry.models import GameVersion

def utc_now(): return datetime.now(timezone.utc)
class PlaywrightAdapter:
    def __init__(self,page): self.page=page
    def _target(self,game,target):
        for t in game.config.targets:
            if t.target_id==target: return t
        return None
    async def observe(self,*,requirement,game):
        raw=await self.page.screenshot(type='png')
        frame_hash=hashlib.sha256(raw).hexdigest()
        fields={}; evidence=[]
        if requirement.target!='__game__':
            t=self._target(game,requirement.target)
            if t is not None and t.selector and game.config.perception.dom_enabled:
                loc=self.page.locator(t.selector).first
                fields['visible']=await loc.is_visible()
                fields['enabled']=await loc.is_enabled()
                try: fields['text']=await loc.inner_text(timeout=500)
                except Exception: fields['text']=''
                evidence.append(EvidenceKind.DOM)
        # A game may expose a deterministic test API. Never execute arbitrary caller-supplied code.
        if game.config.perception.runtime_enabled:
            snapshot=await self.page.evaluate('''() => { const x=window.__TEST_API__; if(!x || typeof x.getState!=='function') return null; const v=x.getState(); return (v && typeof v==='object') ? v : null; }''')
            if snapshot is not None:
                fields.update(snapshot); evidence.append(EvidenceKind.RUNTIME)
        confidence=1.0 if fields else 0.0
        return Observation(observed_at=utc_now(),frame_hash=frame_hash,fields=fields,evidence=tuple(dict.fromkeys(evidence)),confidence=confidence,provider_versions={})
    async def execute(self,*,action,game,manifest):
        kind=action.kind; target=action.target
        if kind=='open_game': await self.page.goto(str(game.config.base_url),wait_until='domcontentloaded')
        elif kind=='wait': await asyncio.sleep(float(action.params.get('duration_ms',0))/1000)
        elif kind in {'click','spin','submit','start_autoplay','pause_autoplay'}:
            t=self._target(game,target or '')
            if t is None or not t.selector: raise RuntimeError(f'target {target!r} is not DOM-interactable')
            loc=self.page.locator(t.selector).first
            count=int(action.params.get('count',1)) if kind in {'spin','start_autoplay'} else 1
            for _ in range(count): await loc.click()
        elif kind=='select':
            t=self._target(game,target or '')
            if t is None or not t.selector: raise RuntimeError(f'target {target!r} is not selectable')
            await self.page.locator(t.selector).select_option(str(action.params['value']))
        elif kind=='enter_text':
            t=self._target(game,target or '')
            if t is None or not t.selector: raise RuntimeError(f'target {target!r} is not editable')
            await self.page.locator(t.selector).fill(str(action.params['text']))
        elif kind=='bet':
            raise RuntimeError('bet requires an explicit game adapter; generic executor refuses money-changing semantics')
        else: raise RuntimeError(f'unsupported action {kind}')
        return utc_now()
