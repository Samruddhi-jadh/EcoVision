from __future__ import annotations

from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any

from fastapi import FastAPI, HTTPException, Request, status
from pydantic import BaseModel, Field

from qa_platform.compiler.anthropic_spec_client import AnthropicTestSpecClient
from qa_platform.compiler.llm_compiler import LLMTestCompiler
from qa_platform.config import Settings
from qa_platform.db.mongo import MongoDatabase
from qa_platform.etp.models import ETPVersionStatus


class Health(BaseModel):
    status: str
    mongodb: str | None = None


class CompileETPRequest(BaseModel):
    model_config = {"extra": "forbid"}

    test_id: str = Field(min_length=1, max_length=200)
    test_case: str = Field(min_length=1, max_length=20_000)


class ETPResponse(BaseModel):
    etp_id: str
    version: int
    test_id: str
    status: str
    content_hash: str
    etp: dict[str, Any]


class ApproveResponse(ETPResponse):
    pass


@dataclass
class AppContainer:
    settings: Settings
    mongo: MongoDatabase
    llm_compiler: LLMTestCompiler | None


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = Settings.from_env()
    mongo = await MongoDatabase.connect(settings)

    llm_compiler: LLMTestCompiler | None = None
    if settings.anthropic_api_key.strip():
        client = AnthropicTestSpecClient(
            api_key=settings.anthropic_api_key,
            model=settings.test_compiler_model,
        )
        llm_compiler = LLMTestCompiler(
            client,
            model=settings.test_compiler_model,
        )

    app.state.container = AppContainer(
        settings=settings,
        mongo=mongo,
        llm_compiler=llm_compiler,
    )

    try:
        yield
    finally:
        mongo.close()


app = FastAPI(
    title="Autonomous Game QA Platform",
    version="0.6.0",
    lifespan=lifespan,
)


def container(request: Request) -> AppContainer:
    value = getattr(request.app.state, "container", None)
    if value is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Application dependencies are not initialized.",
        )
    return value


def to_response(version) -> ETPResponse:
    return ETPResponse(
        etp_id=version.etp_id,
        version=version.version,
        test_id=version.test_id,
        status=version.status.value,
        content_hash=version.content_hash,
        etp=version.etp,
    )


@app.get("/health/live", response_model=Health)
async def live() -> Health:
    return Health(status="ok")


@app.get("/health/ready", response_model=Health)
async def ready(request: Request) -> Health:
    c = container(request)
    if not await c.mongo.ping():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="MongoDB is unavailable.",
        )
    return Health(status="ok", mongodb="ok")


@app.get("/api/v1/etps/{etp_id}/versions/{version}", response_model=ETPResponse)
async def get_etp(request: Request, etp_id: str, version: int) -> ETPResponse:
    c = container(request)
    value = await c.mongo.etp_service.get_version(
        etp_id=etp_id,
        version=version,
    )
    if value is None:
        raise HTTPException(status_code=404, detail="ETP version not found")
    return to_response(value)


@app.post("/api/v1/etps/compile", response_model=ETPResponse)
async def compile_etp(
    request: Request,
    payload: CompileETPRequest,
) -> ETPResponse:
    c = container(request)

    # An existing approved ETP is always preferred and does not require an
    # Anthropic call. This keeps execution/lookup deterministic.
    approved = await c.mongo.etp_service.get_approved(test_id=payload.test_id)
    if approved is not None:
        return to_response(approved)

    if c.llm_compiler is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="ANTHROPIC_API_KEY is not configured; AI Test Compiler is unavailable.",
        )

    try:
        version = await c.mongo.etp_service.resolve_approved_or_compile(
            test_id=payload.test_id,
            test_case=payload.test_case,
            llm_compiler=c.llm_compiler,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc

    return to_response(version)


@app.post(
    "/api/v1/etps/{etp_id}/versions/{version}/approve",
    response_model=ApproveResponse,
)
async def approve_etp(
    request: Request,
    etp_id: str,
    version: int,
) -> ApproveResponse:
    c = container(request)
    try:
        value = await c.mongo.etp_service.approve(
            etp_id=etp_id,
            version=version,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    return ApproveResponse(**to_response(value).model_dump())
