from __future__ import annotations
from datetime import datetime
from pydantic import BaseModel,ConfigDict,Field
class QueueMessage(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    message_id:str; job_id:str; run_id:str; attempt:int=Field(ge=1); enqueued_at:datetime
