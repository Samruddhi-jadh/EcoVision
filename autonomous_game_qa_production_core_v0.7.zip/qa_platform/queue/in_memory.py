from __future__ import annotations
import asyncio,uuid
from collections import deque
from .models import QueueMessage
class InMemoryQueue:
    def __init__(self): self._q=deque(); self._cv=asyncio.Condition(); self.dead=[]
    async def enqueue(self,message):
        async with self._cv: self._q.append(message); self._cv.notify()
        return message.message_id
    async def consume(self,*,consumer,count=1,block_ms=1000):
        async with self._cv:
            if not self._q:
                try: await asyncio.wait_for(self._cv.wait(),block_ms/1000)
                except asyncio.TimeoutError: return ()
            out=[]
            while self._q and len(out)<count: out.append(self._q.popleft())
            return tuple(out)
    async def ack(self,message): return None
    async def dead_letter(self,message,reason): self.dead.append((message,reason))
