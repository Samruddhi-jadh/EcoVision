from __future__ import annotations
import json
from datetime import datetime,timezone
from .models import QueueMessage
class RedisStreamsQueue:
    def __init__(self,redis,*,stream='qa:runs',group='qa-workers',dlq='qa:runs:dlq'):
        self.redis=redis; self.stream=stream; self.group=group; self.dlq=dlq
    async def initialize(self):
        try: await self.redis.xgroup_create(self.stream,self.group,id='0-0',mkstream=True)
        except Exception as exc:
            if 'BUSYGROUP' not in str(exc): raise
    async def enqueue(self,message):
        mid=await self.redis.xadd(self.stream,{'payload':json.dumps(message.model_dump(mode='json'),separators=(',',':'))})
        return mid.decode() if isinstance(mid,bytes) else str(mid)
    async def consume(self,*,consumer,count=1,block_ms=1000):
        rows=await self.redis.xreadgroup(self.group,consumer,{self.stream:'>'},count=count,block=block_ms)
        out=[]
        for _,entries in rows:
            for message_id,fields in entries:
                payload=fields.get(b'payload',fields.get('payload'))
                data=json.loads(payload)
                out.append(QueueMessage.model_validate(data))
        return tuple(out)
    async def ack(self,message): await self.redis.xack(self.stream,self.group,message.message_id)
    async def dead_letter(self,message,reason):
        await self.redis.xadd(self.dlq,{'payload':json.dumps({'message':message.model_dump(mode='json'),'reason':reason},separators=(',',':'))})
