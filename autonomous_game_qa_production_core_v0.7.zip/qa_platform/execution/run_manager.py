from __future__ import annotations
import uuid
from qa_platform.etp.models import ETPVersionStatus
from qa_platform.execution.manifest import build_manifest,verify_manifest_hash
from qa_platform.execution.models import RunStatus
from qa_platform.queue.models import QueueMessage
from qa_platform.validation.service import BatchValidationService
from qa_platform.worker.store import RunStore
from qa_platform.queue.protocol import DurableQueue
class RunManagerError(RuntimeError): pass
class RunManager:
    def __init__(self,*,etp_service,game_service,validator:BatchValidationService,store:RunStore,queue:DurableQueue): self.etp_service=etp_service; self.game_service=game_service; self.validator=validator; self.store=store; self.queue=queue
    async def start_run(self,*,run_id:str|None=None,etp_id:str,test_id:str,etp_version:int,game_id:str,game_version:int,browser:str,browser_version:str,rng_seed:int,viewport_width:int=1280,viewport_height:int=720,device_scale_factor:float=1.0,calibration_version=None,market_snapshot_version=None):
        ev=await self.etp_service.get_version(etp_id=etp_id,version=etp_version)
        if ev is None: raise RunManagerError('ETP version not found')
        if ev.status is not ETPVersionStatus.APPROVED: raise RunManagerError('Only APPROVED ETP versions can run')
        etp=self.etp_service.deserialize_etp(ev)
        game=await self.game_service.get_version(game_id,game_version)
        validation=self.validator.validate(etp_version=ev,etp=etp,game=game,browser=browser,browser_version=browser_version)
        if not validation.executable: raise RunManagerError(validation.model_dump(mode='json'))
        if etp.test_id!=test_id: raise RunManagerError('test_id does not match ETP')
        rid=run_id or str(uuid.uuid4())
        manifest=build_manifest(run_id=rid,etp_id=ev.etp_id,etp_version=ev.version,test_id=ev.test_id,game_id=game.game_id,game_version=game.version,game_build_hash=game.build_hash,browser=browser,browser_version=browser_version,rng_seed=rng_seed,viewport_width=viewport_width,viewport_height=viewport_height,device_scale_factor=device_scale_factor,calibration_version=calibration_version,market_snapshot_version=market_snapshot_version)
        if not verify_manifest_hash(manifest): raise RunManagerError('manifest integrity check failed')
        await self.store.create(manifest)
        await self.store.set_status(rid,RunStatus.QUEUED)
        msg=QueueMessage(message_id=str(uuid.uuid4()),job_id=str(uuid.uuid4()),run_id=rid,attempt=1,enqueued_at=manifest.created_at)
        await self.queue.enqueue(msg)
        return manifest,validation
