from __future__ import annotations
import hashlib,json
from datetime import datetime,timezone
from qa_platform.execution.models import RunManifest

def _canonical(data):
    return json.dumps({k:(v.isoformat() if isinstance(v,datetime) else v) for k,v in data.items()},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def build_manifest(*,run_id,etp_id,etp_version,test_id,game_id,game_version,game_build_hash,browser,browser_version,viewport_width=1280,viewport_height=720,device_scale_factor=1.0,rng_seed=0,model_versions=None,prompt_versions=None,calibration_version=None,market_snapshot_version=None):
    data=dict(run_id=run_id,etp_id=etp_id,etp_version=etp_version,test_id=test_id,game_id=game_id,game_version=game_version,game_build_hash=game_build_hash,browser=browser,browser_version=browser_version,viewport_width=viewport_width,viewport_height=viewport_height,device_scale_factor=device_scale_factor,rng_seed=rng_seed,model_versions=model_versions or {},prompt_versions=prompt_versions or {},calibration_version=calibration_version,market_snapshot_version=market_snapshot_version,created_at=datetime.now(timezone.utc))
    data['manifest_hash']=hashlib.sha256(_canonical(data)).hexdigest(); return RunManifest(**data)
def verify_manifest_hash(manifest:RunManifest)->bool:
    data=manifest.model_dump(mode='python'); expected=data.pop('manifest_hash'); return hashlib.sha256(_canonical(data)).hexdigest()==expected
