from __future__ import annotations
from datetime import datetime
from enum import StrEnum
from typing import Any
from pydantic import BaseModel, ConfigDict, Field
from qa_platform.domain.etp import ExecutionStep, ExecutionTestPlan

class RunPhase(StrEnum): OBSERVE='OBSERVE'; ACT='ACT'; VERIFY='VERIFY'
class RunStatus(StrEnum): CREATED='CREATED'; QUEUED='QUEUED'; RUNNING='RUNNING'; TERMINAL='TERMINAL'; FAILED='FAILED'
class Verdict(StrEnum): PASS='PASS'; PASS_WITH_RECOVERY='PASS_WITH_RECOVERY'; FAIL='FAIL'; BLOCKED='BLOCKED'; INCONCLUSIVE='INCONCLUSIVE'; TIMEOUT='TIMEOUT'; CANCELLED='CANCELLED'; NOT_APPLICABLE='NOT_APPLICABLE'
class GuardDecision(StrEnum): APPROVED='APPROVED'; REJECTED='REJECTED'
class EvidenceKind(StrEnum): DOM='DOM'; OCR='OCR'; CV='CV'; YOLO='YOLO'; VLM='VLM'; RUNTIME='RUNTIME'

class RunManifest(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    run_id:str=Field(min_length=1,max_length=128); etp_id:str; etp_version:int=Field(ge=1); test_id:str
    game_id:str; game_version:int=Field(ge=1); game_build_hash:str=Field(pattern=r'^[0-9a-fA-F]{64}$')
    browser:str; browser_version:str; viewport_width:int=Field(gt=0); viewport_height:int=Field(gt=0); device_scale_factor:float=Field(gt=0)
    rng_seed:int; model_versions:dict[str,str]=Field(default_factory=dict); prompt_versions:dict[str,str]=Field(default_factory=dict)
    calibration_version:str|None=None; market_snapshot_version:str|None=None; created_at:datetime
    manifest_hash:str=Field(pattern=r'^[0-9a-f]{64}$')

class RunJob(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    job_id:str; run_id:str; attempt:int=Field(ge=1); enqueued_at:datetime

class Observation(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    observed_at:datetime; frame_hash:str; fields:dict[str,Any]=Field(default_factory=dict); evidence:tuple[EvidenceKind,...]=(); confidence:float=Field(ge=0,le=1); provider_versions:dict[str,str]=Field(default_factory=dict)

class GameState(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    state:str|None=None; values:dict[str,Any]=Field(default_factory=dict); confidence:float=Field(ge=0,le=1); observed_at:datetime; state_hash:str; provenance:dict[str,tuple[str,...]]=Field(default_factory=dict)

class SemanticAction(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    action_id:str; kind:str; target:str|None=None; params:dict[str,Any]=Field(default_factory=dict); idempotent:bool=True

class ActionProposal(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    action:SemanticAction; source:str='deterministic'; proposed_at:datetime

class GuardResult(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    decision:GuardDecision; reason_code:str; reason:str; checked_at:datetime

class VerificationResult(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    verdict:Verdict; reason_code:str; reason:str; verified_at:datetime; evidence:tuple[str,...]=(); recovery_used:bool=False

class StepContext(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    run_id:str; step:ExecutionStep; phase:RunPhase; attempt:int=Field(ge=1); started_at:datetime

class RunEvent(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True)
    sequence:int=Field(ge=1); run_id:str; event_type:str; occurred_at:datetime; step_id:str|None=None; phase:RunPhase|None=None; payload:dict[str,Any]=Field(default_factory=dict)
