from __future__ import annotations
import asyncio
from datetime import datetime,timezone
from typing import Callable
from qa_platform.domain.etp import ExecutionStep,ExecutionTestPlan,ObservationRequirement
from qa_platform.game_registry.models import GameVersion
from .contracts import Observer,StateFusion,ActionPolicy,ActionGuard,ActionExecutor,Verifier,RunEventSink,CancellationSource
from .models import *

def utc_now(): return datetime.now(timezone.utc)

class ControllerLimits:
    def __init__(self, *, max_run_ms:int=3_600_000, max_actions:int=10_000, max_recovery_attempts:int=0):
        if min(max_run_ms,max_actions)<1 or max_recovery_attempts<0: raise ValueError('invalid controller limits')
        self.max_run_ms=max_run_ms; self.max_actions=max_actions; self.max_recovery_attempts=max_recovery_attempts

class TestController:
    __test__ = False
    def __init__(self, *, observer:Observer, fusion:StateFusion, policy:ActionPolicy, guard:ActionGuard, executor:ActionExecutor, verifier:Verifier, events:RunEventSink, cancel:CancellationSource, limits:ControllerLimits|None=None, sleep:Callable[[float],object]=asyncio.sleep):
        self.observer=observer; self.fusion=fusion; self.policy=policy; self.guard=guard; self.executor=executor; self.verifier=verifier; self.events=events; self.cancel=cancel; self.limits=limits or ControllerLimits(); self.sleep=sleep
    async def run(self, *, manifest:RunManifest, etp:ExecutionTestPlan, game:GameVersion)->Verdict:
        started=utc_now(); actions=0; recovery=0
        await self._emit(manifest,'RUN_STARTED',payload={'etp_version':manifest.etp_version,'game_version':manifest.game_version})
        for step in etp.steps:
            if await self.cancel.is_cancelled(manifest.run_id): return await self._terminal(manifest,Verdict.CANCELLED,'CANCELLED','Run cancellation requested.')
            if (utc_now()-started).total_seconds()*1000 > self.limits.max_run_ms: return await self._terminal(manifest,Verdict.TIMEOUT,'RUN_BUDGET_EXCEEDED','Run time budget exceeded.')
            result=await self._run_step(manifest,step,game,actions,recovery)
            verdict,used_actions,used_recovery=result; actions+=used_actions; recovery+=used_recovery
            if verdict is not Verdict.PASS:
                return await self._terminal(manifest,verdict,'STEP_TERMINAL',f'Step {step.id} ended with {verdict.value}.')
            if actions>self.limits.max_actions: return await self._terminal(manifest,Verdict.BLOCKED,'ACTION_BUDGET_EXCEEDED','Action budget exceeded.')
        return await self._terminal(manifest,Verdict.PASS,'RUN_COMPLETE','All steps verified.')

    async def _run_step(self,manifest,step,game,actions,recovery):
        step_start=utc_now(); max_attempts=step.retry_policy.max_attempts; last_verdict=Verdict.INCONCLUSIVE; attempts_used=0
        for attempt in range(1,max_attempts+1):
            attempts_used=attempt
            if await self.cancel.is_cancelled(manifest.run_id): return Verdict.CANCELLED,0,0
            if (utc_now()-step_start).total_seconds()*1000 > step.timeout_ms: return Verdict.TIMEOUT,0,0
            await self._emit(manifest,'STEP_STARTED',step.id,RunPhase.OBSERVE,{'attempt':attempt})
            req=step.observation_requirement or ObservationRequirement(target='__game__',evidence=('runtime',),min_confidence=0,max_age_ms=max(step.timeout_ms,1))
            before_obs=await self.observer.observe(requirement=req,game=game); before=self.fusion.fuse(before_obs)
            await self._emit(manifest,'OBSERVATION_CAPTURED',step.id,RunPhase.OBSERVE,{'frame_hash':before_obs.frame_hash,'confidence':before.confidence})
            if before.confidence < req.min_confidence:
                last_verdict=Verdict.INCONCLUSIVE
                if attempt<max_attempts: await self._backoff(step.retry_policy.backoff_ms); continue
                return last_verdict,attempts_used,0
            proposal=self.policy.propose(step=step,state=before,run_id=manifest.run_id)
            await self._emit(manifest,'ACTION_PROPOSED',step.id,RunPhase.ACT,proposal.model_dump(mode='json'))
            guard=self.guard.check(step=step,state=before,proposal=proposal,game=game)
            await self._emit(manifest,'GUARD_DECISION',step.id,RunPhase.ACT,guard.model_dump(mode='json'))
            if guard.decision is GuardDecision.REJECTED:
                return Verdict.BLOCKED,attempts_used,0
            action_at=await self.executor.execute(action=proposal.action,game=game,manifest=manifest); actions+=1
            await self._emit(manifest,'ACTION_EXECUTED',step.id,RunPhase.ACT,{'action_at':action_at.isoformat(),'action_id':proposal.action.action_id})
            after_obs=await self.observer.observe(requirement=req,game=game); after=self.fusion.fuse(after_obs)
            await self._emit(manifest,'POST_ACTION_OBSERVATION',step.id,RunPhase.VERIFY,{'frame_hash':after_obs.frame_hash,'observed_at':after.observed_at.isoformat()})
            verification=self.verifier.verify(step=step,before=before,after=after,action_at=action_at,recovery_used=False)
            await self._emit(manifest,'VERIFICATION',step.id,RunPhase.VERIFY,verification.model_dump(mode='json'))
            last_verdict=verification.verdict
            if verification.verdict in {Verdict.PASS,Verdict.PASS_WITH_RECOVERY}: return verification.verdict,1,0
            if verification.verdict in {Verdict.FAIL,Verdict.INCONCLUSIVE} and attempt<max_attempts and step.idempotent:
                await self._backoff(step.retry_policy.backoff_ms); continue
            return verification.verdict,attempts_used,0
        return last_verdict,attempts_used,0

    async def _backoff(self,ms):
        if ms: await self.sleep(ms/1000)
    async def _emit(self,manifest,event_type,step_id=None,phase=None,payload=None):
        await self.events.append(RunEvent(sequence=await self.events.next_sequence(manifest.run_id),run_id=manifest.run_id,event_type=event_type,occurred_at=utc_now(),step_id=step_id,phase=phase,payload=payload or {}))
    async def _terminal(self,manifest,verdict,code,reason):
        await self._emit(manifest,'RUN_TERMINAL',payload={'verdict':verdict.value,'reason_code':code,'reason':reason}); return verdict
