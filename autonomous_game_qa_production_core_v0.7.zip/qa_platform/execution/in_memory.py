from __future__ import annotations
import asyncio
from collections import defaultdict
from qa_platform.execution.models import RunEvent
class InMemoryEventSink:
    def __init__(self): self._events=defaultdict(list); self._lock=asyncio.Lock()
    async def next_sequence(self,run_id):
        async with self._lock: return len(self._events[run_id])+1
    async def append(self,event):
        async with self._lock:
            expected=len(self._events[event.run_id])+1
            if event.sequence!=expected: raise ValueError(f'non-contiguous event sequence: expected {expected}, got {event.sequence}')
            self._events[event.run_id].append(event)
    async def list(self,run_id): return tuple(self._events[run_id])
class InMemoryCancellation:
    def __init__(self): self._cancelled=set(); self._lock=asyncio.Lock()
    async def cancel(self,run_id):
        async with self._lock: self._cancelled.add(run_id)
    async def is_cancelled(self,run_id):
        async with self._lock: return run_id in self._cancelled
