from __future__ import annotations
from datetime import datetime,timezone
import hashlib,json
from qa_platform.domain.etp import ExecutionStep
from qa_platform.game_registry.models import GameVersion
from .models import *

def utc_now(): return datetime.now(timezone.utc)

class DeterministicStateFusion:
    def fuse(self, observation:Observation)->GameState:
        state=observation.fields.get('state')
        canonical=json.dumps(observation.fields,sort_keys=True,separators=(',',':'),default=str).encode()
        return GameState(state=state,values=dict(observation.fields),confidence=observation.confidence,observed_at=observation.observed_at,state_hash=hashlib.sha256(canonical).hexdigest(),provenance={k:tuple(observation.evidence and [x.value for x in observation.evidence] or ()) for k in observation.fields})

class DeterministicActionPolicy:
    def propose(self, *, step:ExecutionStep, state:GameState, run_id:str)->ActionProposal:
        target=step.params.get('target') if isinstance(step.params,dict) else None
        if target is None and step.action.value in {'start_autoplay','pause_autoplay'}: target='autoplay_button' if step.action.value=='start_autoplay' else 'pause_autoplay'
        if target is None and step.observation_requirement: target=step.observation_requirement.target
        return ActionProposal(action=SemanticAction(action_id=f'{run_id}:{step.id}',kind=step.action.value,target=target,params=dict(step.params),idempotent=step.idempotent),proposed_at=utc_now())

class DefaultActionGuard:
    def check(self, *, step, state, proposal, game):
        if step.preconditions and not {x.name for x in step.preconditions}.issubset(set([state.state]) | set(state.values.get('states', []))): return GuardResult(decision=GuardDecision.REJECTED,reason_code='PRECONDITION_FAILED',reason='Current state does not satisfy step preconditions.',checked_at=utc_now())
        if proposal.action.target and proposal.action.target != '__game__' and not any(t.target_id==proposal.action.target for t in game.config.targets): return GuardResult(decision=GuardDecision.REJECTED,reason_code='TARGET_NOT_REGISTERED',reason='Action target is not registered for this GameVersion.',checked_at=utc_now())
        if state.confidence < (step.observation_requirement.min_confidence if step.observation_requirement else 0): return GuardResult(decision=GuardDecision.REJECTED,reason_code='LOW_CONFIDENCE',reason='State confidence is below the step requirement.',checked_at=utc_now())
        if step.observation_requirement and (utc_now()-state.observed_at).total_seconds()*1000 > step.observation_requirement.max_age_ms: return GuardResult(decision=GuardDecision.REJECTED,reason_code='STALE_OBSERVATION',reason='Observation is too old.',checked_at=utc_now())
        if proposal.action.kind=='bet' and game.config.environment.value=='PRODUCTION': return GuardResult(decision=GuardDecision.REJECTED,reason_code='REAL_MONEY_BLOCKED',reason='Betting is blocked in production environments.',checked_at=utc_now())
        return GuardResult(decision=GuardDecision.APPROVED,reason_code='APPROVED',reason='Action satisfies deterministic guard policy.',checked_at=utc_now())

class DefaultVerifier:
    def verify(self, *, step,before,after,action_at,recovery_used):
        if after.observed_at <= action_at: return VerificationResult(verdict=Verdict.INCONCLUSIVE,reason_code='STALE_POST_ACTION_STATE',reason='Post-action observation timestamp is not later than action timestamp.',verified_at=utc_now(),recovery_used=recovery_used)
        if step.expected_transition:
            if before.state != step.expected_transition.from_state or after.state != step.expected_transition.to_state:
                return VerificationResult(verdict=Verdict.FAIL,reason_code='EXPECTED_TRANSITION_NOT_OBSERVED',reason=f'Expected {step.expected_transition.from_state}->{step.expected_transition.to_state}, got {before.state}->{after.state}.',verified_at=utc_now(),recovery_used=recovery_used)
        for assertion in step.assertions:
            actual=after.values.get(assertion.target) if assertion.target else None
            if assertion.type.value=='element_visible' and actual is not True: return VerificationResult(verdict=Verdict.FAIL,reason_code='ASSERTION_FAILED',reason=f'{assertion.target} is not visible.',verified_at=utc_now(),recovery_used=recovery_used)
            if assertion.type.value=='element_enabled' and actual is not True: return VerificationResult(verdict=Verdict.FAIL,reason_code='ASSERTION_FAILED',reason=f'{assertion.target} is not enabled.',verified_at=utc_now(),recovery_used=recovery_used)
            if assertion.type.value=='text_equals' and actual != assertion.expected: return VerificationResult(verdict=Verdict.FAIL,reason_code='ASSERTION_FAILED',reason=f'{assertion.target} text mismatch.',verified_at=utc_now(),recovery_used=recovery_used)
            if assertion.type.value=='text_contains' and (not isinstance(actual,str) or str(assertion.expected) not in actual): return VerificationResult(verdict=Verdict.FAIL,reason_code='ASSERTION_FAILED',reason=f'{assertion.target} text does not contain expected value.',verified_at=utc_now(),recovery_used=recovery_used)
            if assertion.type.value=='value_equals' and actual != assertion.expected: return VerificationResult(verdict=Verdict.FAIL,reason_code='ASSERTION_FAILED',reason=f'{assertion.target} value mismatch.',verified_at=utc_now(),recovery_used=recovery_used)
            if assertion.type.value=='value_in_range' and (not isinstance(actual,(int,float)) or actual<assertion.min_value or actual>assertion.max_value): return VerificationResult(verdict=Verdict.FAIL,reason_code='ASSERTION_FAILED',reason=f'{assertion.target} outside range.',verified_at=utc_now(),recovery_used=recovery_used)
            if assertion.type.value=='state_equals' and after.state != assertion.expected: return VerificationResult(verdict=Verdict.FAIL,reason_code='ASSERTION_FAILED',reason='State assertion failed.',verified_at=utc_now(),recovery_used=recovery_used)
        return VerificationResult(verdict=Verdict.PASS_WITH_RECOVERY if recovery_used else Verdict.PASS,reason_code='VERIFIED',reason='Expected transition and assertions verified.',verified_at=utc_now(),recovery_used=recovery_used)
