from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from qa_platform.compiler.compiler import (
    ExecutionTestPlanCompiler,
    verify_etp_hash,
)
from qa_platform.domain.etp import ExecutionTestPlan
from qa_platform.domain.test_spec import TestSpec

from .models import ETPVersion, ETPVersionStatus
from qa_platform.repositories.etp_repository import ETPRepository


class ETPValidationError(ValueError):
    pass


class ETPService:

    def __init__(
        self,
        repository: ETPRepository,
        compiler: ExecutionTestPlanCompiler,
    ) -> None:
        self._repository = repository
        self._compiler = compiler

    async def initialize(self) -> None:
        await self._repository.ensure_indexes()

    def compile_spec(self, spec: TestSpec) -> ExecutionTestPlan:
        """Deterministically compile a validated TestSpec into an ETP."""
        return self._compiler.compile(spec)

    async def create_version(
        self,
        etp: ExecutionTestPlan,
    ) -> ETPVersion:

        if not verify_etp_hash(etp):
            raise ETPValidationError(
                "ETP content hash verification failed."
            )

        existing = await self._repository.find_by_hash(
            test_id=etp.test_id,
            content_hash=etp.content_hash,
        )

        if existing is not None:
            return existing

        latest = await self._repository.get_latest(
            test_id=etp.test_id,
        )

        next_version = (
            1
            if latest is None
            else latest.version + 1
        )

        now = datetime.now(UTC)

        version = ETPVersion(
            etp_id=etp.test_id,
            version=next_version,
            test_id=etp.test_id,
            schema_version=etp.etp_schema_version,
            source_spec_version=etp.source_spec_version,
            status=ETPVersionStatus.DRAFT,
            content_hash=etp.content_hash,
            etp=etp.model_dump(mode="json"),
            created_at=now,
        )

        return await self._repository.create(version)

    async def get_version(
        self,
        *,
        etp_id: str,
        version: int,
    ) -> ETPVersion | None:
        return await self._repository.get(
            etp_id=etp_id,
            version=version,
        )

    async def get_latest(
        self,
        *,
        test_id: str,
    ) -> ETPVersion | None:
        return await self._repository.get_latest(
            test_id=test_id,
        )

    async def get_approved(
        self,
        *,
        test_id: str,
    ) -> ETPVersion | None:
        return await self._repository.get_approved(
            test_id=test_id,
        )

    async def approve(
        self,
        *,
        etp_id: str,
        version: int,
    ) -> ETPVersion:
        return await self._repository.approve(
            etp_id=etp_id,
            version=version,
        )

    async def deprecate(
        self,
        *,
        etp_id: str,
        version: int,
    ) -> ETPVersion:
        return await self._repository.deprecate(
            etp_id=etp_id,
            version=version,
        )

    def deserialize_etp(
        self,
        version: ETPVersion,
    ) -> ExecutionTestPlan:
        etp = ExecutionTestPlan.model_validate(
            version.etp
        )

        if not verify_etp_hash(etp):
            raise ETPValidationError(
                "Stored ETP hash verification failed."
            )

        if etp.content_hash != version.content_hash:
            raise ETPValidationError(
                "Stored ETP content hash does not match "
                "ETP version metadata."
            )

        return etp

    async def resolve_approved_or_compile(
        self,
        *,
        test_id: str,
        test_case: str,
        llm_compiler: Any,
    ) -> ETPVersion:
        """
        Authoring-time resolver.

        1. Return approved ETP if one exists.
        2. Otherwise call AI Test Compiler.
        3. Deterministically compile TestSpec -> ETP.
        4. Persist as DRAFT.
        5. Human review/approval happens separately.
        """

        existing = await self.get_approved(
            test_id=test_id,
        )

        if existing is not None:
            return existing

        spec, _metadata = await llm_compiler.compile(
            test_case=test_case,
        )

        if spec.test_id != test_id:
            raise ETPValidationError(
                "Compiler returned a different test_id."
            )

        etp = self._compiler.compile(spec)

        return await self.create_version(etp)