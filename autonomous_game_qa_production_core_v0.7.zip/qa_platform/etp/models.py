from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ETPVersionStatus(StrEnum):
    DRAFT = "DRAFT"
    APPROVED = "APPROVED"
    DEPRECATED = "DEPRECATED"


class ETPVersion(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
    )

    etp_id: str
    version: int = Field(ge=1)

    test_id: str

    schema_version: str
    source_spec_version: str

    status: ETPVersionStatus

    content_hash: str = Field(
        pattern=r"^[0-9a-f]{64}$",
    )

    etp: dict[str, Any]

    created_at: datetime
    activated_at: datetime | None = None
    deprecated_at: datetime | None = None