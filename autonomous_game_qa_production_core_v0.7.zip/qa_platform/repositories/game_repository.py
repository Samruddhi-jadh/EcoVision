from __future__ import annotations

from typing import Protocol

from qa_platform.game_registry.models import GameVersion


class GameRepositoryError(Exception):
    pass


class GameAlreadyExistsError(GameRepositoryError):
    pass


class GameVersionNotFoundError(GameRepositoryError):
    pass


class GameNotFoundError(GameRepositoryError):
    pass


class InvalidGameVersionTransitionError(GameRepositoryError):
    pass


class GameRepository(Protocol):

    async def ensure_indexes(self) -> None:
        ...

    async def create_version(
        self,
        version: GameVersion,
    ) -> GameVersion:
        ...

    async def get_version(
        self,
        game_id: str,
        version: int,
    ) -> GameVersion:
        ...

    async def get_latest_version(
        self,
        game_id: str,
    ) -> GameVersion | None:
        ...

    async def get_active_version(
        self,
        game_id: str,
    ) -> GameVersion | None:
        ...

    async def find_by_build_hash(
        self,
        game_id: str,
        build_hash: str,
    ) -> GameVersion | None:
        ...

    async def activate_version(
        self,
        game_id: str,
        version: int,
    ) -> GameVersion:
        ...

    async def deprecate_version(
        self,
        game_id: str,
        version: int,
    ) -> GameVersion:
        ...