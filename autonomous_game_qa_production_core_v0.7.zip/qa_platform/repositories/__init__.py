"""Repository interfaces and implementations.

Imports are intentionally not re-exported here. Keeping package initialization
side-effect free prevents circular imports between repositories and services.
"""
