from __future__ import annotations
from datetime import UTC,datetime
from typing import Any
from pymongo import ASCENDING,DESCENDING
from pymongo.errors import DuplicateKeyError
from pymongo.asynchronous.collection import AsyncCollection
from qa_platform.etp.models import ETPVersion,ETPVersionStatus
from qa_platform.repositories.etp_repository import ETPAlreadyExistsError,ETPInvalidTransitionError,ETPRepository
class MongoDBETPRepository(ETPRepository):
    COLLECTION_NAME='etp_versions'
    def __init__(self,collection:AsyncCollection[dict[str,Any]]): self._collection=collection
    async def ensure_indexes(self):
        await self._collection.create_index([('etp_id',ASCENDING),('version',ASCENDING)],unique=True,name='uq_etp_version')
        await self._collection.create_index([('test_id',ASCENDING),('content_hash',ASCENDING)],unique=True,name='uq_test_content_hash')
        await self._collection.create_index([('test_id',ASCENDING),('status',ASCENDING),('version',DESCENDING)],name='ix_test_status_version')
        await self._collection.create_index([('test_id',ASCENDING)],unique=True,partialFilterExpression={'status':ETPVersionStatus.APPROVED.value},name='uq_test_approved')
    async def create(self,version):
        try: await self._collection.insert_one(version.model_dump(mode='python'))
        except DuplicateKeyError as exc: raise ETPAlreadyExistsError('ETP version or content already exists') from exc
        return version
    async def _get(self,q):
        d=await self._collection.find_one(q)
        if d is None:return None
        d.pop('_id',None); return ETPVersion.model_validate(d)
    async def get(self,*,etp_id,version): return await self._get({'etp_id':etp_id,'version':version})
    async def get_latest(self,*,test_id):
        d=await self._collection.find_one({'test_id':test_id},sort=[('version',DESCENDING)])
        if d is None:return None
        d.pop('_id',None); return ETPVersion.model_validate(d)
    async def get_approved(self,*,test_id): return await self._get({'test_id':test_id,'status':ETPVersionStatus.APPROVED.value})
    async def find_by_hash(self,*,test_id,content_hash): return await self._get({'test_id':test_id,'content_hash':content_hash})
    async def approve(self,*,etp_id,version):
        current=await self.get(etp_id=etp_id,version=version)
        if current is None: raise ETPInvalidTransitionError('ETP version does not exist')
        if current.status is ETPVersionStatus.APPROVED:return current
        if current.status is ETPVersionStatus.DEPRECATED:raise ETPInvalidTransitionError('Deprecated ETP versions cannot be approved')
        now=datetime.now(UTC)
        await self._collection.update_many({'test_id':current.test_id,'status':ETPVersionStatus.APPROVED.value},{'$set':{'status':ETPVersionStatus.DEPRECATED.value,'deprecated_at':now}})
        result=await self._collection.update_one({'etp_id':etp_id,'version':version,'status':ETPVersionStatus.DRAFT.value},{'$set':{'status':ETPVersionStatus.APPROVED.value,'activated_at':now}})
        if result.modified_count!=1: raise ETPInvalidTransitionError('ETP approval failed')
        return await self.get(etp_id=etp_id,version=version)
    async def deprecate(self,*,etp_id,version):
        current=await self.get(etp_id=etp_id,version=version)
        if current is None: raise ETPInvalidTransitionError('ETP version does not exist')
        if current.status is ETPVersionStatus.DEPRECATED:return current
        result=await self._collection.update_one({'etp_id':etp_id,'version':version,'status':{'$in':[ETPVersionStatus.DRAFT.value,ETPVersionStatus.APPROVED.value]}},{'$set':{'status':ETPVersionStatus.DEPRECATED.value,'deprecated_at':datetime.now(UTC)}})
        if result.modified_count!=1:raise ETPInvalidTransitionError('ETP could not be deprecated')
        return await self.get(etp_id=etp_id,version=version)
