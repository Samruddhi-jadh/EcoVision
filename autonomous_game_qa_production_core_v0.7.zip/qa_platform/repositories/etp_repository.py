from __future__ import annotations

from typing import Protocol

from qa_platform.etp.models import ETPVersion


class ETPAlreadyExistsError(RuntimeError):
    pass


class ETPNotFoundError(RuntimeError):
    pass


class ETPInvalidTransitionError(RuntimeError):
    pass


class ETPRepository(Protocol):

    async def ensure_indexes(self) -> None:
        ...

    async def create(
        self,
        version: ETPVersion,
    ) -> ETPVersion:
        ...

    async def get(
        self,
        *,
        etp_id: str,
        version: int,
    ) -> ETPVersion | None:
        ...

    async def get_latest(
        self,
        *,
        test_id: str,
    ) -> ETPVersion | None:
        ...

    async def get_approved(
        self,
        *,
        test_id: str,
    ) -> ETPVersion | None:
        ...

    async def find_by_hash(
        self,
        *,
        test_id: str,
        content_hash: str,
    ) -> ETPVersion | None:
        ...

    async def approve(
        self,
        *,
        etp_id: str,
        version: int,
    ) -> ETPVersion:
        ...

    async def deprecate(
        self,
        *,
        etp_id: str,
        version: int,
    ) -> ETPVersion:
        ...