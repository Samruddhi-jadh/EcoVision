from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pymongo import ASCENDING, DESCENDING
from pymongo.errors import DuplicateKeyError
from pymongo.asynchronous.collection import AsyncCollection

from qa_platform.game_registry.models import GameVersion, GameVersionStatus
from qa_platform.repositories.game_repository import (
    GameAlreadyExistsError,
    GameNotFoundError,
    GameRepository,
    GameVersionNotFoundError,
    InvalidGameVersionTransitionError,
)


class MongoDBGameRepository(GameRepository):
    COLLECTION_NAME = "game_versions"

    def __init__(self, collection: AsyncCollection[dict[str, Any]]) -> None:
        self._collection = collection

    async def ensure_indexes(self) -> None:
        await self._collection.create_index(
            [("game_id", ASCENDING), ("version", ASCENDING)],
            unique=True,
            name="uq_game_version",
        )
        await self._collection.create_index(
            [("game_id", ASCENDING), ("build_hash", ASCENDING)],
            unique=True,
            name="uq_game_build_hash",
        )
        await self._collection.create_index(
            [("game_id", ASCENDING), ("status", ASCENDING), ("version", DESCENDING)],
            name="ix_game_status_version",
        )
        await self._collection.create_index(
            [("game_id", ASCENDING)],
            unique=True,
            partialFilterExpression={"status": GameVersionStatus.ACTIVE.value},
            name="uq_game_active",
        )

    async def create_version(self, version: GameVersion) -> GameVersion:
        try:
            await self._collection.insert_one(version.model_dump(mode="python"))
        except DuplicateKeyError as exc:
            raise GameAlreadyExistsError(
                "Game version or build hash already exists"
            ) from exc
        return version

    async def _get(self, query: dict[str, Any]) -> GameVersion | None:
        document = await self._collection.find_one(query)
        if document is None:
            return None
        document.pop("_id", None)
        return GameVersion.model_validate(document)

    async def get_version(self, game_id: str, version: int) -> GameVersion:
        result = await self._get({"game_id": game_id, "version": version})
        if result is None:
            raise GameVersionNotFoundError(
                f"game version not found: {game_id}:{version}"
            )
        return result

    async def get_latest_version(self, game_id: str) -> GameVersion | None:
        document = await self._collection.find_one(
            {"game_id": game_id},
            sort=[("version", DESCENDING)],
        )
        if document is None:
            return None
        document.pop("_id", None)
        return GameVersion.model_validate(document)

    async def get_active_version(self, game_id: str) -> GameVersion | None:
        return await self._get(
            {
                "game_id": game_id,
                "status": GameVersionStatus.ACTIVE.value,
            }
        )

    async def find_by_build_hash(
        self,
        game_id: str,
        build_hash: str,
    ) -> GameVersion | None:
        return await self._get(
            {"game_id": game_id, "build_hash": build_hash}
        )

    async def activate_version(self, game_id: str, version: int) -> GameVersion:
        current = await self._get({"game_id": game_id, "version": version})
        if current is None:
            raise GameVersionNotFoundError(
                f"game version not found: {game_id}:{version}"
            )
        if current.status is GameVersionStatus.ACTIVE:
            return current
        if current.status is GameVersionStatus.DEPRECATED:
            raise InvalidGameVersionTransitionError(
                "Deprecated game versions cannot be activated"
            )

        now = datetime.now(UTC)
        await self._collection.update_many(
            {
                "game_id": game_id,
                "status": GameVersionStatus.ACTIVE.value,
            },
            {
                "$set": {
                    "status": GameVersionStatus.DEPRECATED.value,
                    "deprecated_at": now,
                }
            },
        )
        result = await self._collection.update_one(
            {
                "game_id": game_id,
                "version": version,
                "status": GameVersionStatus.DRAFT.value,
            },
            {
                "$set": {
                    "status": GameVersionStatus.ACTIVE.value,
                    "activated_at": now,
                }
            },
        )
        if result.modified_count != 1:
            raise InvalidGameVersionTransitionError(
                "Game version activation failed"
            )
        return await self.get_version(game_id, version)

    async def deprecate_version(self, game_id: str, version: int) -> GameVersion:
        current = await self._get({"game_id": game_id, "version": version})
        if current is None:
            raise GameVersionNotFoundError(
                f"game version not found: {game_id}:{version}"
            )
        if current.status is GameVersionStatus.DEPRECATED:
            return current

        result = await self._collection.update_one(
            {
                "game_id": game_id,
                "version": version,
                "status": {
                    "$in": [
                        GameVersionStatus.DRAFT.value,
                        GameVersionStatus.ACTIVE.value,
                    ]
                },
            },
            {
                "$set": {
                    "status": GameVersionStatus.DEPRECATED.value,
                    "deprecated_at": datetime.now(UTC),
                }
            },
        )
        if result.modified_count != 1:
            raise InvalidGameVersionTransitionError(
                "Game version could not be deprecated"
            )
        return await self.get_version(game_id, version)
