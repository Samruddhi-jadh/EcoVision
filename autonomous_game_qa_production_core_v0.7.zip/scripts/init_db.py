from __future__ import annotations

import asyncio

from qa_platform.config import Settings
from qa_platform.db.mongo import MongoDatabase


async def main() -> None:
    settings = Settings.from_env()
    mongo = await MongoDatabase.connect(settings)
    try:
        collections = await mongo.database.list_collection_names()
        print("MongoDB: connected")
        print(f"Database: {settings.mongodb_database}")
        print("Indexes: initialized")
        print("Collections:")
        for name in sorted(collections):
            print(f"  - {name}")
        print()
        print("ETP collection: etp_versions")
        print("Game collection: game_versions")
    finally:
        mongo.close()


if __name__ == "__main__":
    asyncio.run(main())
