from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from qa_platform.compiler.anthropic_spec_client import AnthropicTestSpecClient
from qa_platform.compiler.llm_compiler import LLMTestCompiler
from qa_platform.config import Settings
from qa_platform.db.mongo import MongoDatabase


async def main() -> None:
    parser = argparse.ArgumentParser(description="Compile a natural-language test into a persisted ETP draft.")
    parser.add_argument("--test-id", required=True)
    parser.add_argument("--test", required=True)
    parser.add_argument("--output-dir", default="artifacts")
    args = parser.parse_args()

    settings = Settings.from_env()
    if not settings.anthropic_api_key.strip():
        raise SystemExit("ANTHROPIC_API_KEY is not configured in .env")

    mongo = await MongoDatabase.connect(settings)
    try:
        client = AnthropicTestSpecClient(
            api_key=settings.anthropic_api_key,
            model=settings.test_compiler_model,
        )
        compiler = LLMTestCompiler(client, model=settings.test_compiler_model)

        print("[1/5] MongoDB connected and indexes initialized")
        print("[2/5] Calling AI Test Compiler...")
        version = await mongo.etp_service.resolve_approved_or_compile(
            test_id=args.test_id,
            test_case=args.test,
            llm_compiler=compiler,
        )
        print("[3/5] TestSpec validated")
        print("[4/5] Deterministic ETP compiled and persisted")
        print("[5/5] ETP content hash verified")

        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{version.etp_id}.v{version.version}.json"
        output_file.write_text(
            json.dumps(version.etp, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

        print()
        print("SUCCESS")
        print(f"ETP ID: {version.etp_id}")
        print(f"Version: {version.version}")
        print(f"Status: {version.status.value}")
        print(f"Hash: {version.content_hash}")
        print(f"File: {output_file}")
    finally:
        mongo.close()


if __name__ == "__main__":
    asyncio.run(main())
