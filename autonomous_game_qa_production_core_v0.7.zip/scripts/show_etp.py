from __future__ import annotations

import argparse
import asyncio
import json

from qa_platform.config import Settings
from qa_platform.db.mongo import MongoDatabase


async def main() -> None:
    parser = argparse.ArgumentParser(description="Read an ETP version from MongoDB.")
    parser.add_argument("--etp-id", required=True)
    parser.add_argument("--version", type=int, required=True)
    args = parser.parse_args()

    mongo = await MongoDatabase.connect(Settings.from_env())
    try:
        value = await mongo.etp_service.get_version(
            etp_id=args.etp_id,
            version=args.version,
        )
        if value is None:
            raise SystemExit("ETP version not found")
        print(json.dumps(value.model_dump(mode="json"), indent=2, ensure_ascii=False))
    finally:
        mongo.close()


if __name__ == "__main__":
    asyncio.run(main())
