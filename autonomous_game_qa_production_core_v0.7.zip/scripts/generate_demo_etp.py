from __future__ import annotations

import asyncio
import json
from pathlib import Path

from qa_platform.compiler.compiler import verify_etp_hash
from qa_platform.config import Settings
from qa_platform.db.mongo import MongoDatabase
from qa_platform.domain.test_spec import (
    ActionType,
    ObservationRequirement,
    TestSpec,
    TestStep,
)


async def main() -> None:
    settings = Settings.from_env()
    mongo = await MongoDatabase.connect(settings)
    try:
        spec = TestSpec(
            test_id="autoplay-overlay-001",
            name="Verify 10 autoplay spins pause on overlay",
            description="Verify autoplay pauses when the overlay appears.",
            tags=("autoplay", "overlay"),
            steps=(
                TestStep(
                    id="start-autoplay",
                    action=ActionType.START_AUTOPLAY,
                    params={"count": 10},
                ),
                TestStep(
                    id="pause-autoplay",
                    action=ActionType.PAUSE_AUTOPLAY,
                    params={},
                    observation_requirement=ObservationRequirement(
                        target="game_overlay",
                        evidence=("dom",),
                        min_confidence=0.90,
                        max_age_ms=1000,
                    ),
                ),
            ),
        )

        etp = mongo.etp_service.compile_spec(spec)
        assert verify_etp_hash(etp)
        version = await mongo.etp_service.create_version(etp)

        output_dir = Path("artifacts")
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{version.etp_id}.v{version.version}.json"
        output_file.write_text(
            json.dumps(version.etp, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

        print("ETP GENERATED")
        print(f"ETP ID: {version.etp_id}")
        print(f"Version: {version.version}")
        print(f"Status: {version.status.value}")
        print(f"Hash valid: {verify_etp_hash(etp)}")
        print(f"MongoDB: {settings.mongodb_database}.etp_versions")
        print(f"File: {output_file}")
    finally:
        mongo.close()


if __name__ == "__main__":
    asyncio.run(main())
