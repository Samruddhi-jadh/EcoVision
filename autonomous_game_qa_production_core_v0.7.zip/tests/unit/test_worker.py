import pytest
from datetime import datetime,timezone
from qa_platform.queue.in_memory import InMemoryQueue
from qa_platform.queue.models import QueueMessage
from qa_platform.worker.store import InMemoryRunStore
from qa_platform.worker.worker import ExecutionWorker
from qa_platform.execution.models import RunManifest,RunStatus,Verdict
class C:
 async def run(self,**kwargs): return Verdict.PASS
@pytest.mark.asyncio
async def test_worker_executes_once_and_terminal():
 store=InMemoryRunStore(); q=InMemoryQueue(); now=datetime.now(timezone.utc)
 m=RunManifest(run_id='r1',etp_id='t',etp_version=1,test_id='t',game_id='demo-game',game_version=1,game_build_hash='a'*64,browser='chromium',browser_version='1',viewport_width=1,viewport_height=1,device_scale_factor=1,rng_seed=1,created_at=now,manifest_hash='b'*64)
 await store.create(m); msg=QueueMessage(message_id='m',job_id='j',run_id='r1',attempt=1,enqueued_at=now); await q.enqueue(msg)
 class E: test_id='t'
 class G: version=1; build_hash='a'*64
 async def le(m): return E()
 async def lg(m): return G()
 w=ExecutionWorker(queue=q,store=store,controller_factory=lambda:C(),etp_loader=le,game_loader=lg)
 await w.process(msg); assert await store.get_status('r1') is RunStatus.TERMINAL
