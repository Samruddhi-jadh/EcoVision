import pytest

from qa_platform.compiler.llm_compiler import (
    LLMCompilationError,
    LLMTestCompiler,
)
from qa_platform.domain.test_spec import TestSpec


@pytest.mark.asyncio
async def test_llm_compiler_returns_validated_spec() -> None:
    class FakeClient:
        async def generate_test_spec(
            self,
            *,
            system_prompt: str,
            test_case: str,
            model: str,
        ) -> TestSpec:
            return TestSpec(
                test_id="autoplay-001",
                name="Autoplay test",
                steps=(
                    {
                        "id": "start",
                        "action": "click",
                        "params": {
                            "target": "autoplay_button"
                        },
                        "observation_requirement": {
                            "target": "autoplay_button",
                            "evidence": ["runtime"],
                            "min_confidence": 0.5,
                            "max_age_ms": 1000
                        },
                    },
                ),
            )

    compiler = LLMTestCompiler(
        FakeClient(),
        model="test-model",
    )

    spec, metadata = await compiler.compile(
        test_case="Start autoplay.",
    )

    assert spec.test_id == "autoplay-001"
    assert metadata.provider == "anthropic"