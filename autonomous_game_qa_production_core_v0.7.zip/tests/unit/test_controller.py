import pytest
from datetime import datetime,timezone
from qa_platform.domain.etp import *
from qa_platform.execution.controller import TestController
from qa_platform.execution.deterministic import DeterministicStateFusion,DeterministicActionPolicy,DefaultActionGuard,DefaultVerifier
from qa_platform.execution.in_memory import InMemoryEventSink,InMemoryCancellation
from qa_platform.execution.models import RunManifest,Verdict
from qa_platform.adapters.synthetic import ScriptedObserver,RecordingExecutor
from qa_platform.game_registry.models import *

def game():
 return GameVersion(game_id='demo-game',version=1,build_id='b',build_hash='a'*64,status=GameVersionStatus.ACTIVE,config=GameConfig(environment=GameEnvironment.TEST,base_url='https://example.com',capabilities=frozenset({GameCapability.CANVAS,GameCapability.MANUAL_SPIN,GameCapability.AUTOPLAY}),targets=(TargetDefinition(target_id='x',description='x',kind='button',semantic_name='x'),)),created_at=datetime.now(timezone.utc),activated_at=datetime.now(timezone.utc))
def manifest():
 return RunManifest(run_id='r1',etp_id='t1',etp_version=1,test_id='t1',game_id='demo-game',game_version=1,game_build_hash='a'*64,browser='chromium',browser_version='1',viewport_width=1280,viewport_height=720,device_scale_factor=1,rng_seed=1,created_at=datetime.now(timezone.utc),manifest_hash='b'*64)
@pytest.mark.asyncio
async def test_controller_runs_observe_act_verify():
 step=ExecutionStep(id='s1',action=ActionType.CLICK,params={'target':'x'},observation_requirement=ObservationRequirement(target='x',evidence=('runtime',),min_confidence=0.5,max_age_ms=10000),expected_transition=ExpectedTransition(from_state='READY',to_state='DONE'),assertions=(),timeout_ms=10000,retry_policy=RetryPolicy(max_attempts=1),idempotent=True)
 etp=ExecutionTestPlan(test_id='t1',name='x',steps=(step,),content_hash='0'*64)
 # hash is irrelevant to controller
 obs=ScriptedObserver(['READY','DONE']); ex=RecordingExecutor(); events=InMemoryEventSink(); cancel=InMemoryCancellation()
 c=TestController(observer=obs,fusion=DeterministicStateFusion(),policy=DeterministicActionPolicy(),guard=DefaultActionGuard(),executor=ex,verifier=DefaultVerifier(),events=events,cancel=cancel)
 result=await c.run(manifest=manifest(),etp=etp,game=game())
 assert result is Verdict.PASS
 assert len(ex.actions)==1
 assert [e.event_type for e in await events.list('r1')][-1]=='RUN_TERMINAL'
