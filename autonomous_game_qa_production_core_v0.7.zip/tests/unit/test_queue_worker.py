import pytest
from datetime import datetime,timezone
from qa_platform.queue.in_memory import InMemoryQueue
from qa_platform.queue.models import QueueMessage
@pytest.mark.asyncio
async def test_queue_roundtrip():
 q=InMemoryQueue(); m=QueueMessage(message_id='m',job_id='j',run_id='r',attempt=1,enqueued_at=datetime.now(timezone.utc)); await q.enqueue(m); got=await q.consume(consumer='w'); assert got==(m,); await q.ack(m)
