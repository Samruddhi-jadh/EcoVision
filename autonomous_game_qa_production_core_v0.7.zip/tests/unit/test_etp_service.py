import hashlib,json
from datetime import datetime,timezone
from unittest.mock import AsyncMock,Mock
import pytest
from qa_platform.domain.etp import *
from qa_platform.domain.test_spec import TestSpec,TestStep
from qa_platform.etp.services import ETPService
from qa_platform.etp.models import ETPVersionStatus
class Repo:
 def __init__(self,approved=None): self.approved=approved; self.created=[]
 async def ensure_indexes(self): pass
 async def get_approved(self,*,test_id): return self.approved
 async def find_by_hash(self,*,test_id,content_hash): return next((x for x in self.created if x.content_hash==content_hash),None)
 async def get_latest(self,*,test_id): return self.created[-1] if self.created else None
 async def create(self,v): self.created.append(v); return v
 async def get(self,*,etp_id,version): return None
 async def approve(self,**kwargs): raise NotImplementedError
 async def deprecate(self,**kwargs): raise NotImplementedError
class Compiler:
 def compile(self,spec):
  step=ExecutionStep(id='s',action=ActionType.WAIT,params={'duration_ms':1},timeout_ms=1000,retry_policy=RetryPolicy(),idempotent=True)
  p={'etp_schema_version':'1.0','source_spec_version':'1.0','test_id':spec.test_id,'name':spec.name,'description':spec.description,'tags':list(spec.tags),'steps':[step.model_dump(mode='json')]}
  h=hashlib.sha256(json.dumps(p,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
  return ExecutionTestPlan(**p,content_hash=h)
@pytest.mark.asyncio
async def test_approved_skips_llm():
 v=Mock(test_id='t'); r=Repo(v); llm=Mock(); result=await ETPService(r,Compiler()).resolve_approved_or_compile(test_id='t',test_case='x',llm_compiler=llm); assert result is v; llm.compile.assert_not_called()
@pytest.mark.asyncio
async def test_missing_compiles_draft():
 r=Repo(); llm=Mock(); llm.compile=AsyncMock(return_value=(TestSpec(test_id='t',name='T',steps=(TestStep(id='s',action=ActionType.WAIT,params={'duration_ms':1}),)),None)); result=await ETPService(r,Compiler()).resolve_approved_or_compile(test_id='t',test_case='x',llm_compiler=llm); assert result.status is ETPVersionStatus.DRAFT; llm.compile.assert_awaited_once()
