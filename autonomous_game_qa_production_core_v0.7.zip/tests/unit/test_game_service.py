import pytest

from qa_platform.game_registry.models import (
    GameCapability,
    GameConfig,
    GameEnvironment,
    TargetDefinition,
    GameVersionStatus,
)

from qa_platform.game_registry.services import (
    GameRegistryService,
)


class FakeRepository:

    def __init__(self) -> None:
        self.items = {}

    async def ensure_indexes(self) -> None:
        return None

    async def get_latest_version(
        self,
        game_id: str,
    ):
        versions = [
            item
            for item in self.items.values()
            if item.game_id == game_id
        ]

        if not versions:
            return None

        return max(
            versions,
            key=lambda item: item.version,
        )

    async def find_by_build_hash(
        self,
        game_id: str,
        build_hash: str,
    ):
        return next(
            (
                item
                for item in self.items.values()
                if item.game_id == game_id
                and item.build_hash == build_hash
            ),
            None,
        )

    async def create_version(self, version):

        key = (
            version.game_id,
            version.version,
        )

        if key in self.items:
            from qa_platform.repositories.game_repository import (
                GameAlreadyExistsError,
            )

            raise GameAlreadyExistsError()

        self.items[key] = version

        return version

    async def get_version(
        self,
        game_id,
        version,
    ):
        return self.items[
            (
                game_id,
                version,
            )
        ]

    async def get_active_version(
        self,
        game_id,
    ):
        versions = [
            item
            for item in self.items.values()
            if item.game_id == game_id
            and item.status is GameVersionStatus.ACTIVE
        ]

        if not versions:
            return None

        return max(
            versions,
            key=lambda item: item.version,
        )

    async def activate_version(
        self,
        game_id,
        version,
    ):
        raise NotImplementedError

    async def deprecate_version(
        self,
        game_id,
        version,
    ):
        raise NotImplementedError


def make_config() -> GameConfig:

    return GameConfig(
        environment=GameEnvironment.TEST,
        base_url="https://game.test.example",
        capabilities=frozenset(
            {
                GameCapability.CANVAS,
                GameCapability.AUTOPLAY,
            }
        ),
        targets=(
            TargetDefinition(
                target_id="pause_overlay",
                description="Pause overlay",
                kind="overlay",
                semantic_name="pause_overlay",
            ),
        ),
    )


@pytest.mark.asyncio
async def test_first_game_version_is_v1():

    service = GameRegistryService(
        FakeRepository()
    )

    result = await service.register_version(
        game_id="demo-game",
        build_id="build-1",
        build_hash="1" * 64,
        config=make_config(),
    )

    assert result.version == 1
    assert result.status is GameVersionStatus.DRAFT


@pytest.mark.asyncio
async def test_second_build_gets_v2():

    service = GameRegistryService(
        FakeRepository()
    )

    first = await service.register_version(
        game_id="demo-game",
        build_id="build-1",
        build_hash="1" * 64,
        config=make_config(),
    )

    second = await service.register_version(
        game_id="demo-game",
        build_id="build-2",
        build_hash="2" * 64,
        config=make_config(),
    )

    assert first.version == 1
    assert second.version == 2


@pytest.mark.asyncio
async def test_same_build_is_idempotent():

    service = GameRegistryService(
        FakeRepository()
    )

    first = await service.register_version(
        game_id="demo-game",
        build_id="build-1",
        build_hash="1" * 64,
        config=make_config(),
    )

    second = await service.register_version(
        game_id="demo-game",
        build_id="build-1",
        build_hash="1" * 64,
        config=make_config(),
    )

    assert first == second


@pytest.mark.asyncio
async def test_capability_check():

    service = GameRegistryService(
        FakeRepository()
    )

    game = await service.register_version(
        game_id="demo-game",
        build_id="build-1",
        build_hash="1" * 64,
        config=make_config(),
    )

    compatible, missing = (
        service.check_compatibility(
            game,
            frozenset(
                {
                    GameCapability.AUTOPLAY,
                }
            ),
        )
    )

    assert compatible is True
    assert missing == ()


@pytest.mark.asyncio
async def test_missing_capability():

    service = GameRegistryService(
        FakeRepository()
    )

    game = await service.register_version(
        game_id="demo-game",
        build_id="build-1",
        build_hash="1" * 64,
        config=make_config(),
    )

    compatible, missing = (
        service.check_compatibility(
            game,
            frozenset(
                {
                    GameCapability.BETTING,
                }
            ),
        )
    )

    assert compatible is False
    assert missing == ("BETTING",)