from __future__ import annotations

from datetime import UTC, datetime

import pytest

pytest.importorskip("pymongo")

from qa_platform.game_registry.models import (
    GameCapability,
    GameConfig,
    GameEnvironment,
    GameVersion,
    GameVersionStatus,
)
from qa_platform.repositories.mongodb_game_repository import MongoDBGameRepository


class FakeResult:
    def __init__(self, modified_count: int = 1):
        self.modified_count = modified_count


class FakeCollection:
    def __init__(self):
        self.documents = []
        self.indexes = []

    async def create_index(self, *args, **kwargs):
        self.indexes.append((args, kwargs))

    async def insert_one(self, document):
        self.documents.append(document)

    async def find_one(self, query, sort=None, projection=None):
        matches = [d for d in self.documents if all(d.get(k) == v for k, v in query.items())]
        if not matches:
            return None
        if sort:
            key, direction = sort[0]
            matches.sort(key=lambda d: d[key], reverse=direction < 0)
        result = dict(matches[0])
        result["_id"] = "fake"
        return result

    async def update_many(self, query, update):
        for document in self.documents:
            if all(document.get(k) == v for k, v in query.items()):
                document.update(update["$set"])
        return FakeResult()

    async def update_one(self, query, update):
        for document in self.documents:
            if all(document.get(k) == v for k, v in query.items()):
                document.update(update["$set"])
                return FakeResult()
        return FakeResult(0)


@pytest.mark.asyncio
async def test_game_repository_initializes_indexes():
    collection = FakeCollection()
    repository = MongoDBGameRepository(collection)  # type: ignore[arg-type]

    await repository.ensure_indexes()

    names = {kwargs["name"] for _, kwargs in collection.indexes}
    assert names == {
        "uq_game_version",
        "uq_game_build_hash",
        "ix_game_status_version",
        "uq_game_active",
    }
