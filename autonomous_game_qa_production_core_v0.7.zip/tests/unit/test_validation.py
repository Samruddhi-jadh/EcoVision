from datetime import datetime,timezone
from qa_platform.domain.etp import *
from qa_platform.etp.models import *
from qa_platform.game_registry.models import *
from qa_platform.validation.service import BatchValidationService

def mk(etp_status=ETPVersionStatus.APPROVED, caps=None):
 step=ExecutionStep(id='s',action=ActionType.START_AUTOPLAY,params={'count':10},observation_requirement=ObservationRequirement(target='autoplay_button',evidence=('runtime',),min_confidence=.5,max_age_ms=1000),expected_transition=ExpectedTransition(from_state='READY',to_state='AUTOPLAY_RUNNING'),assertions=(),timeout_ms=1000,retry_policy=RetryPolicy(),idempotent=True)
 e0=ExecutionTestPlan(test_id='t',name='t',steps=(step,),content_hash='0'*64)
 from qa_platform.compiler.compiler import verify_etp_hash
 import hashlib,json
 payload=e0.model_dump(mode='json'); payload.pop('content_hash'); h=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
 e=e0.model_copy(update={'content_hash':h})
 v=ETPVersion(etp_id='t',version=1,test_id='t',schema_version='1.0',source_spec_version='1.0',status=etp_status,content_hash=e.content_hash,etp=e.model_dump(mode='json'),created_at=datetime.now(timezone.utc),activated_at=datetime.now(timezone.utc) if etp_status is ETPVersionStatus.APPROVED else None)
 g=GameVersion(game_id='demo-game',version=1,build_id='b',build_hash='a'*64,status=GameVersionStatus.ACTIVE,config=GameConfig(environment=GameEnvironment.TEST,base_url='https://example.com',capabilities=frozenset(caps or {GameCapability.CANVAS,GameCapability.AUTOPLAY}),targets=(TargetDefinition(target_id='autoplay_button',description='a',kind='button',semantic_name='a'),)),created_at=datetime.now(timezone.utc),activated_at=datetime.now(timezone.utc))
 return v,e,g

def test_approved_autoplay_valid():
 v,e,g=mk(); r=BatchValidationService().validate(etp_version=v,etp=e,game=g,browser='chromium',browser_version='1'); assert r.executable

def test_draft_blocked():
 v,e,g=mk(ETPVersionStatus.DRAFT); r=BatchValidationService().validate(etp_version=v,etp=e,game=g,browser='chromium',browser_version='1'); assert not r.executable

def test_missing_autoplay_capability():
 v,e,g=mk(caps={GameCapability.CANVAS}); r=BatchValidationService().validate(etp_version=v,etp=e,game=g,browser='chromium',browser_version='1'); assert any(x.code=='GAME_CAPABILITY_MISSING' for x in r.errors)
