from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from qa_platform.game_registry.models import (
    GameCapability,
    GameConfig,
    GameEnvironment,
    GameVersion,
    GameVersionStatus,
    TargetDefinition,
)


def make_config() -> GameConfig:
    return GameConfig(
        environment=GameEnvironment.TEST,
        base_url="https://game.test.example",
        capabilities=frozenset(
            {
                GameCapability.CANVAS,
                GameCapability.AUTOPLAY,
            }
        ),
        targets=(
            TargetDefinition(
                target_id="pause_overlay",
                description="Autoplay pause overlay",
                kind="overlay",
                semantic_name="pause_overlay",
            ),
        ),
    )


def test_invalid_build_hash_rejected() -> None:

    with pytest.raises(ValidationError):
        GameVersion(
            game_id="demo-game",
            version=1,
            build_id="build-1",
            build_hash="invalid",
            config=make_config(),
            created_at=datetime.now(timezone.utc),
        )


def test_active_requires_activation_timestamp() -> None:

    with pytest.raises(ValidationError):
        GameVersion(
            game_id="demo-game",
            version=1,
            build_id="build-1",
            build_hash="a" * 64,
            status=GameVersionStatus.ACTIVE,
            config=make_config(),
            created_at=datetime.now(timezone.utc),
        )


def test_deprecated_requires_timestamp() -> None:

    with pytest.raises(ValidationError):
        GameVersion(
            game_id="demo-game",
            version=1,
            build_id="build-1",
            build_hash="a" * 64,
            status=GameVersionStatus.DEPRECATED,
            config=make_config(),
            created_at=datetime.now(timezone.utc),
        )


def test_target_requires_selector_or_semantic_name() -> None:

    with pytest.raises(ValidationError):
        TargetDefinition(
            target_id="button",
            description="Spin button",
            kind="button",
        )


def test_duplicate_targets_rejected() -> None:

    with pytest.raises(ValidationError):
        GameConfig(
            environment=GameEnvironment.TEST,
            base_url="https://game.test.example",
            capabilities=frozenset(
                {GameCapability.CANVAS}
            ),
            targets=(
                TargetDefinition(
                    target_id="spin",
                    description="Spin",
                    kind="button",
                    semantic_name="spin",
                ),
                TargetDefinition(
                    target_id="spin",
                    description="Another spin",
                    kind="button",
                    semantic_name="spin",
                ),
            ),
        )